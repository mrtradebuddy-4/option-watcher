import { type WatchlistItem, type InsertWatchlistItem, type AiAnalysis, type InsertAiAnalysis, type UpstoxTokenRecord, type ChatConversation, type InsertChatConversation, type ChatMessage, type InsertChatMessage } from "@shared/schema";
import { upstoxTokens, watchlistItems, aiAnalyses, chatConversations, chatMessages } from "@shared/schema";
import { randomUUID, createCipheriv, createDecipheriv, randomBytes } from "crypto";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

function getEncryptionKey(): string {
  const secret = process.env.SESSION_SECRET;
  if (!secret || secret.length < 32) {
    throw new Error("SESSION_SECRET must be at least 32 characters for secure token encryption");
  }
  return secret.slice(0, 32);
}

const IV_LENGTH = 16;

function encrypt(text: string): string {
  const iv = randomBytes(IV_LENGTH);
  const cipher = createCipheriv('aes-256-cbc', Buffer.from(getEncryptionKey()), iv);
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  return iv.toString('hex') + ':' + encrypted;
}

function decrypt(encryptedText: string): string {
  const parts = encryptedText.split(':');
  const iv = Buffer.from(parts[0], 'hex');
  const encrypted = parts[1];
  const decipher = createDecipheriv('aes-256-cbc', Buffer.from(getEncryptionKey()), iv);
  let decrypted = decipher.update(encrypted, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  return decrypted;
}

export interface IStorage {
  getWatchlist(): Promise<WatchlistItem[]>;
  addToWatchlist(item: InsertWatchlistItem): Promise<WatchlistItem>;
  removeFromWatchlist(id: string): Promise<void>;
  getLatestAnalysis(symbol: string, expirationDate: string): Promise<AiAnalysis | undefined>;
  createAnalysis(analysis: InsertAiAnalysis): Promise<AiAnalysis>;
  getUpstoxToken(): Promise<UpstoxTokenRecord | null>;
  saveUpstoxToken(accessToken: string, expiry: Date): Promise<void>;
  clearUpstoxToken(): Promise<void>;
  getOrCreateConversation(symbol: string, expirationDate: string, analysisId?: string): Promise<ChatConversation>;
  getConversationMessages(conversationId: string, limit?: number): Promise<ChatMessage[]>;
  addChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
}

export class MemStorage implements IStorage {
  private watchlist: Map<string, WatchlistItem>;
  private analyses: Map<string, AiAnalysis>;
  private upstoxToken: UpstoxTokenRecord | null;
  private conversations: Map<string, ChatConversation>;
  private messages: Map<string, ChatMessage[]>;

  constructor() {
    this.watchlist = new Map();
    this.analyses = new Map();
    this.upstoxToken = null;
    this.conversations = new Map();
    this.messages = new Map();
  }

  async getWatchlist(): Promise<WatchlistItem[]> {
    return Array.from(this.watchlist.values()).sort(
      (a, b) => new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime()
    );
  }

  async addToWatchlist(item: InsertWatchlistItem): Promise<WatchlistItem> {
    // Check if already exists
    const existing = Array.from(this.watchlist.values()).find(
      w => w.symbol.toUpperCase() === item.symbol.toUpperCase()
    );
    if (existing) {
      return existing;
    }

    const id = randomUUID();
    const watchlistItem: WatchlistItem = {
      id,
      symbol: item.symbol.toUpperCase(),
      addedAt: new Date(),
    };
    this.watchlist.set(id, watchlistItem);
    return watchlistItem;
  }

  async removeFromWatchlist(id: string): Promise<void> {
    this.watchlist.delete(id);
  }

  async getLatestAnalysis(symbol: string, expirationDate: string): Promise<AiAnalysis | undefined> {
    const key = `${symbol.toUpperCase()}-${expirationDate}`;
    return this.analyses.get(key);
  }

  async createAnalysis(analysis: InsertAiAnalysis): Promise<AiAnalysis> {
    const id = randomUUID();
    const key = `${analysis.symbol.toUpperCase()}-${analysis.expirationDate}`;
    const aiAnalysis: AiAnalysis = {
      id,
      symbol: analysis.symbol.toUpperCase(),
      expirationDate: analysis.expirationDate,
      analysis: analysis.analysis,
      createdAt: new Date(),
    };
    this.analyses.set(key, aiAnalysis);
    return aiAnalysis;
  }

  async getUpstoxToken(): Promise<UpstoxTokenRecord | null> {
    if (!this.upstoxToken) return null;
    if (new Date() > this.upstoxToken.expiry) {
      this.upstoxToken = null;
      return null;
    }
    return this.upstoxToken;
  }

  async saveUpstoxToken(accessToken: string, expiry: Date): Promise<void> {
    this.upstoxToken = {
      id: "default",
      accessToken,
      expiry,
      savedAt: new Date(),
    };
  }

  async clearUpstoxToken(): Promise<void> {
    this.upstoxToken = null;
  }

  async getOrCreateConversation(symbol: string, expirationDate: string, analysisId?: string): Promise<ChatConversation> {
    const key = `${symbol.toUpperCase()}-${expirationDate}`;
    let conv = this.conversations.get(key);
    if (!conv) {
      const id = randomUUID();
      conv = {
        id,
        symbol: symbol.toUpperCase(),
        expirationDate,
        analysisId: analysisId || null,
        createdAt: new Date(),
      };
      this.conversations.set(key, conv);
      this.messages.set(id, []);
    }
    return conv;
  }

  async getConversationMessages(conversationId: string, limit?: number): Promise<ChatMessage[]> {
    const msgs = this.messages.get(conversationId) || [];
    return limit ? msgs.slice(-limit) : msgs;
  }

  async addChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const id = randomUUID();
    const msg: ChatMessage = {
      id,
      conversationId: message.conversationId,
      role: message.role,
      content: message.content,
      createdAt: new Date(),
    };
    const msgs = this.messages.get(message.conversationId) || [];
    msgs.push(msg);
    this.messages.set(message.conversationId, msgs);
    return msg;
  }
}

export class DatabaseStorage implements IStorage {
  private watchlistCache: Map<string, WatchlistItem>;
  private analysisCache: Map<string, AiAnalysis>;

  constructor() {
    this.watchlistCache = new Map();
    this.analysisCache = new Map();
  }

  async getWatchlist(): Promise<WatchlistItem[]> {
    const items = await db.select().from(watchlistItems);
    return items.map(item => ({
      id: item.id,
      symbol: item.symbol,
      addedAt: item.addedAt,
    })).sort((a, b) => new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime());
  }

  async addToWatchlist(item: InsertWatchlistItem): Promise<WatchlistItem> {
    const existing = await db.select().from(watchlistItems)
      .where(eq(watchlistItems.symbol, item.symbol.toUpperCase()));
    if (existing.length > 0) {
      return {
        id: existing[0].id,
        symbol: existing[0].symbol,
        addedAt: existing[0].addedAt,
      };
    }

    const id = randomUUID();
    const result = await db.insert(watchlistItems).values({
      id,
      symbol: item.symbol.toUpperCase(),
    }).returning();

    return {
      id: result[0].id,
      symbol: result[0].symbol,
      addedAt: result[0].addedAt,
    };
  }

  async removeFromWatchlist(id: string): Promise<void> {
    await db.delete(watchlistItems).where(eq(watchlistItems.id, id));
  }

  async getLatestAnalysis(symbol: string, expirationDate: string): Promise<AiAnalysis | undefined> {
    const results = await db.select().from(aiAnalyses)
      .where(and(
        eq(aiAnalyses.symbol, symbol.toUpperCase()),
        eq(aiAnalyses.expirationDate, expirationDate)
      ))
      .orderBy(desc(aiAnalyses.createdAt))
      .limit(1);
    
    if (results.length === 0) return undefined;
    
    const matching = results[0];
    return {
      id: matching.id,
      symbol: matching.symbol,
      expirationDate: matching.expirationDate,
      analysis: matching.analysis,
      createdAt: matching.createdAt,
    };
  }

  async createAnalysis(analysis: InsertAiAnalysis): Promise<AiAnalysis> {
    const id = randomUUID();
    const result = await db.insert(aiAnalyses).values({
      id,
      symbol: analysis.symbol.toUpperCase(),
      expirationDate: analysis.expirationDate,
      analysis: analysis.analysis,
    }).returning();

    return {
      id: result[0].id,
      symbol: result[0].symbol,
      expirationDate: result[0].expirationDate,
      analysis: result[0].analysis,
      createdAt: result[0].createdAt,
    };
  }

  async getUpstoxToken(): Promise<UpstoxTokenRecord | null> {
    try {
      const results = await db.select().from(upstoxTokens)
        .where(eq(upstoxTokens.id, "default"));
      
      if (results.length === 0) return null;
      
      const record = results[0];
      const expiry = new Date(record.expiry);
      
      if (new Date() > expiry) {
        await this.clearUpstoxToken();
        return null;
      }

      const decryptedToken = decrypt(record.accessToken);
      return {
        id: record.id,
        accessToken: decryptedToken,
        expiry,
        savedAt: record.savedAt,
      };
    } catch (error) {
      console.error("Failed to get Upstox token:", error);
      return null;
    }
  }

  async saveUpstoxToken(accessToken: string, expiry: Date): Promise<void> {
    try {
      const encryptedToken = encrypt(accessToken);
      
      await db.delete(upstoxTokens).where(eq(upstoxTokens.id, "default"));
      await db.insert(upstoxTokens).values({
        id: "default",
        accessToken: encryptedToken,
        expiry,
      });
      console.log("Upstox token encrypted and saved to database");
    } catch (error) {
      console.error("Failed to save Upstox token:", error);
      throw error;
    }
  }

  async clearUpstoxToken(): Promise<void> {
    try {
      await db.delete(upstoxTokens).where(eq(upstoxTokens.id, "default"));
      console.log("Upstox token cleared from database");
    } catch (error) {
      console.error("Failed to clear Upstox token:", error);
    }
  }

  async getOrCreateConversation(symbol: string, expirationDate: string, analysisId?: string): Promise<ChatConversation> {
    const symbolUpper = symbol.toUpperCase();
    
    const existing = await db.select().from(chatConversations)
      .where(and(
        eq(chatConversations.symbol, symbolUpper),
        eq(chatConversations.expirationDate, expirationDate)
      ))
      .orderBy(desc(chatConversations.createdAt))
      .limit(1);
    
    if (existing.length > 0) {
      return existing[0];
    }

    const id = randomUUID();
    const result = await db.insert(chatConversations).values({
      id,
      symbol: symbolUpper,
      expirationDate,
      analysisId: analysisId || null,
    }).returning();

    return result[0];
  }

  async getConversationMessages(conversationId: string, limit?: number): Promise<ChatMessage[]> {
    const query = db.select().from(chatMessages)
      .where(eq(chatMessages.conversationId, conversationId))
      .orderBy(chatMessages.createdAt);
    
    const results = await query;
    return limit ? results.slice(-limit) : results;
  }

  async addChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const id = randomUUID();
    const result = await db.insert(chatMessages).values({
      id,
      conversationId: message.conversationId,
      role: message.role,
      content: message.content,
    }).returning();

    return result[0];
  }
}

export const storage = new DatabaseStorage();
