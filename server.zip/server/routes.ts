import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import YahooFinance from "yahoo-finance2";
import OpenAI from "openai";
import axios from "axios";
import { insertWatchlistItemSchema, insertAiAnalysisSchema } from "@shared/schema";
import type { OptionContract, OptionChainData, StockQuote } from "@shared/schema";

// WebSocket connections store
const wsClients = new Set<WebSocket>();

// Last known prices for change detection
const lastPrices: Map<string, number> = new Map();

// Broadcast message to all connected clients
function broadcast(message: object) {
  const data = JSON.stringify(message);
  wsClients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(data);
    }
  });
}

// Create yahoo-finance2 instance (v3 API)
const yahooFinance = new YahooFinance();

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Upstox configuration
const UPSTOX_API_KEY = process.env.UPSTOX_API_KEY;
const UPSTOX_API_SECRET = process.env.UPSTOX_API_SECRET;
const UPSTOX_REDIRECT_URI = process.env.REPLIT_DEV_DOMAIN 
  ? `https://${process.env.REPLIT_DEV_DOMAIN}/api/upstox/callback`
  : "http://localhost:5000/api/upstox/callback";

// In-memory cache for Upstox access token
let upstoxAccessToken: string | null = null;
let upstoxTokenExpiry: Date | null = null;
let upstoxOAuthState: string | null = null;

// Load saved token from storage (async - called on first request or route registration)
async function loadSavedToken() {
  try {
    const savedToken = await storage.getUpstoxToken();
    if (savedToken) {
      upstoxAccessToken = savedToken.accessToken;
      upstoxTokenExpiry = savedToken.expiry;
      console.log("Restored Upstox session from storage, expires:", savedToken.expiry.toISOString());
    }
  } catch (error) {
    console.error("Failed to load saved Upstox token:", error);
  }
}

// Generate random state for OAuth CSRF protection
function generateOAuthState(): string {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

// Popular Indian indices for quick access (moved to top for all routes)
const INDIAN_INDICES: Record<string, string> = {
  "NIFTY": "NSE_INDEX|Nifty 50",
  "BANKNIFTY": "NSE_INDEX|Nifty Bank",
  "FINNIFTY": "NSE_INDEX|Nifty Fin Service",
  "MIDCPNIFTY": "NSE_INDEX|NIFTY MID SELECT",
  "SENSEX": "BSE_INDEX|SENSEX",
};

// NSE Equity stocks mapping (Symbol -> ISIN)
const NSE_STOCKS: Record<string, string> = {
  // Nifty 50 & Major Stocks
  "RELIANCE": "INE002A01018",
  "TCS": "INE467B01029",
  "HDFCBANK": "INE040A01034",
  "INFY": "INE009A01021",
  "ICICIBANK": "INE090A01021",
  "HINDUNILVR": "INE030A01027",
  "SBIN": "INE062A01020",
  "BHARTIARTL": "INE397D01024",
  "ITC": "INE154A01025",
  "KOTAKBANK": "INE237A01028",
  "LT": "INE018A01030",
  "AXISBANK": "INE238A01034",
  "ASIANPAINT": "INE021A01026",
  "MARUTI": "INE585B01010",
  "HCLTECH": "INE860A01027",
  "SUNPHARMA": "INE044A01036",
  "WIPRO": "INE075A01022",
  "ULTRACEMCO": "INE481G01011",
  "ONGC": "INE213A01029",
  "NTPC": "INE733E01010",
  "POWERGRID": "INE752E01010",
  "M&M": "INE101A01026",
  "COALINDIA": "INE522F01014",
  "JSWSTEEL": "INE019A01038",
  "DRREDDY": "INE089A01023",
  "CIPLA": "INE059A01026",
  "NESTLEIND": "INE239A01016",
  "DIVISLAB": "INE361B01024",
  "TECHM": "INE669C01036",
  "GRASIM": "INE047A01021",
  "BRITANNIA": "INE216A01030",
  "HINDALCO": "INE038A01020",
  "APOLLOHOSP": "INE437A01024",
  "EICHERMOT": "INE066A01021",
  "HEROMOTOCO": "INE158A01026",
  "INDUSINDBK": "INE095A01012",
  "BPCL": "INE541A01028",
  "VEDL": "INE205A01025",
  "SHREECEM": "INE070A01015",
  "HDFC": "INE001A01036",
  "PNB": "INE160A01022",
  "BANKBARODA": "INE028A01039",
  "IOC": "INE242A01010",
  "ZOMATO": "INE758T01015",
  "PAYTM": "INE982J01020",
  "NYKAA": "INE388Y01029",
  "DELHIVERY": "INE148O01028",
  "ZYDUSLIFE": "INE010B01027",
  "PIDILITIND": "INE318A01026",
  "SIEMENS": "INE003A01024",
  "HAVELLS": "INE176B01034",
  "ABB": "INE117A01022",
  "BERGEPAINT": "INE463A01038",
  "GODREJCP": "INE102D01028",
  "DABUR": "INE016A01026",
  "MARICO": "INE196A01026",
  "COLPAL": "INE259A01022",
  "JUBLFOOD": "INE797F01020",
  "PAGEIND": "INE761H01022",
  "MUTHOOTFIN": "INE414G01012",
  "SBICARD": "INE018E01016",
  "SBILIFE": "INE123W01016",
  "ICICIPRULI": "INE726G01019",
  "ICICIGI": "INE765G01017",
  "HDFCLIFE": "INE795G01014",
  "AMBUJACEM": "INE079A01024",
  "ACC": "INE012A01025",
  "DLF": "INE271C01023",
  "GODREJPROP": "INE484J01027",
  "OBEROIRLTY": "INE093I01010",
  "PRESTIGE": "INE811K01011",
  "LODHA": "INE670K01029",
  
  // BAJAJ GROUP
  "BAJFINANCE": "INE296A01032",
  "BAJAJFINSV": "INE918I01026",
  "BAJAJ-AUTO": "INE917I01010",
  "BAJAJAUTO": "INE917I01010",
  "BAJAJHLDNG": "INE118A01012",
  "BAJAJCON": "INE933K01021",
  
  // ADANI GROUP
  "ADANIENT": "INE423A01024",
  "ADANIPORTS": "INE742F01042",
  "ADANIGREEN": "INE364U01010",
  "ADANIPOWER": "INE814H01011",
  "ADANITRANS": "INE931S01010",
  "ADANIENSOL": "INE931S01010",
  "ATGL": "INE399L01023",
  "AWL": "INE699H01024",
  "ADANIWILMAR": "INE699H01024",
  
  // TATA GROUP
  "TATAMOTORS": "INE155A01022",
  "TATASTEEL": "INE081A01020",
  "TITAN": "INE280A01028",
  "TATAPOWER": "INE245A01021",
  "TATACONSUM": "INE192A01025",
  "TATATECH": "INE142M01025",
  "TATACOMM": "INE151A01013",
  "TATAELXSI": "INE670A01012",
  "TATACHEM": "INE092A01019",
  "TATAINVEST": "INE672A01018",
  "TATACOFFEE": "INE493A01027",
  "TATAMETALI": "INE056C01010",
  "TRENT": "INE849A01020",
  "VOLTAS": "INE226A01021",
  "INDHOTEL": "INE053A01029",
  "NELCO": "INE045B01015",
  
  // Other Popular Stocks
  "IRCTC": "INE335Y01020",
  "PERSISTENT": "INE262H01013",
  "LTIM": "INE214T01019",
  "LTTS": "INE010V01017",
  "POLYCAB": "INE455K01017",
  "JINDALSTEL": "INE749A01030",
  "SAIL": "INE114A01011",
  "NMDC": "INE584A01023",
  "GAIL": "INE129A01019",
  "BHEL": "INE257A01026",
  "HAL": "INE066F01020",
  "BEL": "INE263A01024",
  "IRFC": "INE053F01010",
  "PFC": "INE134E01011",
  "RECLTD": "INE020B01018",
  "CANBK": "INE476A01014",
  "UNIONBANK": "INE692A01016",
  "IDFCFIRSTB": "INE092T01019",
  "FEDERALBNK": "INE171A01029",
  "RBLBANK": "INE976G01028",
  "BANDHANBNK": "INE545U01014",
  "AUBANK": "INE949L01017",
  "CHOLAFIN": "INE121A01024",
  "MANAPPURAM": "INE522D01027",
  "LICHSGFIN": "INE115A01026",
  "PNBHOUSING": "INE572E01012",
  "CANFINHOME": "INE477A01020",
  "MRF": "INE883A01011",
  "BOSCHLTD": "INE323A01026",
  "MOTHERSON": "INE775A01035",
  "ASHOKLEY": "INE208A01029",
  "BHARATFORG": "INE465A01025",
  "EXIDEIND": "INE302A01020",
  "AUROPHARMA": "INE406A01037",
  "LUPIN": "INE326A01037",
  "ALKEM": "INE540L01014",
  "TORNTPHARM": "INE685A01028",
  "BIOCON": "INE376G01013",
  "LALPATHLAB": "INE600L01024",
  "METROPOLIS": "INE112L01020",
  "MAXHEALTH": "INE027H01010",
  "MEDANTA": "INE874R01019",
  "DMART": "INE192R01011",
  "IDEA": "INE669E01016",
  "MPHASIS": "INE356A01018",
  "COFORGE": "INE591G01017",
  "HDFCAMC": "INE127D01025",
  "ICICIMGMT": "INE247M01018",
  "MAXFIN": "INE180A01020",
};

// Function to get instrument key from symbol
function getInstrumentKey(symbol: string): string {
  const upperSymbol = symbol.toUpperCase();
  
  // Check if it's an index
  if (INDIAN_INDICES[upperSymbol]) {
    return INDIAN_INDICES[upperSymbol];
  }
  
  // Check if it's a known stock
  if (NSE_STOCKS[upperSymbol]) {
    return `NSE_EQ|${NSE_STOCKS[upperSymbol]}`;
  }
  
  // Try common variations
  const variations = [
    upperSymbol,
    upperSymbol.replace("-", ""),
    upperSymbol.replace("&", ""),
  ];
  
  for (const variant of variations) {
    if (NSE_STOCKS[variant]) {
      return `NSE_EQ|${NSE_STOCKS[variant]}`;
    }
  }
  
  // Fallback - this likely won't work but we try
  return `NSE_EQ|${upperSymbol}`;
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Load saved Upstox token on startup
  await loadSavedToken();

  // Get stock quote
  app.get("/api/quote/:symbol", async (req, res) => {
    try {
      const { symbol } = req.params;
      const quote = await yahooFinance.quote(symbol.toUpperCase());
      
      if (!quote) {
        return res.status(404).json({ error: "Stock not found" });
      }

      const stockQuote: StockQuote = {
        symbol: quote.symbol,
        shortName: quote.shortName || quote.symbol,
        regularMarketPrice: quote.regularMarketPrice || 0,
        regularMarketChange: quote.regularMarketChange || 0,
        regularMarketChangePercent: quote.regularMarketChangePercent || 0,
        regularMarketVolume: quote.regularMarketVolume || 0,
        marketCap: quote.marketCap || 0,
        open: (quote as any).regularMarketOpen || 0,
        high: (quote as any).regularMarketDayHigh || 0,
        low: (quote as any).regularMarketDayLow || 0,
        close: quote.regularMarketPrice || 0,
        previousClose: (quote as any).regularMarketPreviousClose || 0,
        yearHigh: (quote as any).fiftyTwoWeekHigh || 0,
        yearLow: (quote as any).fiftyTwoWeekLow || 0,
      };

      res.json(stockQuote);
    } catch (error: any) {
      console.error("Error fetching quote:", error.message, error.stack);
      res.status(500).json({ error: "Failed to fetch stock quote", details: error.message });
    }
  });

  // Get available expiration dates
  app.get("/api/expirations/:symbol", async (req, res) => {
    try {
      const { symbol } = req.params;
      const options = await yahooFinance.options(symbol.toUpperCase());
      
      if (!options || !options.expirationDates) {
        return res.status(404).json({ error: "No options data found" });
      }

      // Convert dates to ISO strings
      const expirationDates = options.expirationDates.map(date => {
        if (date instanceof Date) {
          return date.toISOString().split('T')[0];
        }
        return date;
      });

      res.json({ expirationDates });
    } catch (error: any) {
      console.error("Error fetching expirations:", error.message, error.stack);
      res.status(500).json({ error: "Failed to fetch expiration dates", details: error.message });
    }
  });

  // Get option chain for a specific expiration
  app.get("/api/options/:symbol/:expiration", async (req, res) => {
    try {
      const { symbol, expiration } = req.params;
      const expirationDate = new Date(expiration);
      
      const options = await yahooFinance.options(symbol.toUpperCase(), {
        date: expirationDate,
      });
      
      if (!options) {
        return res.status(404).json({ error: "No options data found" });
      }

      const mapOption = (opt: any): OptionContract => ({
        contractSymbol: opt.contractSymbol || "",
        strike: opt.strike || 0,
        lastPrice: opt.lastPrice || 0,
        bid: opt.bid || 0,
        ask: opt.ask || 0,
        change: opt.change || 0,
        percentChange: opt.percentChange || 0,
        volume: opt.volume || 0,
        openInterest: opt.openInterest || 0,
        oiChange: 0,
        impliedVolatility: opt.impliedVolatility || 0,
        inTheMoney: opt.inTheMoney || false,
      });

      const underlyingPrice = options.underlyingSymbol ? 
        (await yahooFinance.quote(symbol.toUpperCase())).regularMarketPrice || 0 : 0;
      
      const calls = (options.options?.[0]?.calls || []).map(mapOption);
      const puts = (options.options?.[0]?.puts || []).map(mapOption);
      
      // Calculate summary
      const totalCallOI = calls.reduce((sum, c) => sum + (c.openInterest || 0), 0);
      const totalPutOI = puts.reduce((sum, p) => sum + (p.openInterest || 0), 0);
      const pcr = totalCallOI > 0 ? totalPutOI / totalCallOI : 0;
      const atmStrike = calls.length > 0 ? 
        calls.reduce((prev, curr) => Math.abs(curr.strike - underlyingPrice) < Math.abs(prev.strike - underlyingPrice) ? curr : prev).strike : 0;

      const optionChainData: OptionChainData = {
        symbol: symbol.toUpperCase(),
        underlyingPrice,
        expirationDates: (options.expirationDates || []).map(d => 
          d instanceof Date ? d.toISOString().split('T')[0] : d
        ),
        selectedExpiration: expiration,
        calls,
        puts,
        summary: {
          spotPrice: underlyingPrice,
          maxPain: atmStrike,
          pcr,
          totalCallOI,
          totalPutOI,
          ceBuildup: 0,
          peBuildup: 0,
          trendDirection: "NEUTRAL",
          atmStrike,
        },
        lastUpdated: new Date().toISOString(),
      };

      res.json(optionChainData);
    } catch (error: any) {
      console.error("Error fetching options:", error);
      res.status(500).json({ error: "Failed to fetch option chain" });
    }
  });

  // Get existing analysis
  app.get("/api/analysis/:symbol/:expiration", async (req, res) => {
    try {
      const { symbol, expiration } = req.params;
      const analysis = await storage.getLatestAnalysis(symbol.toUpperCase(), expiration);
      
      if (!analysis) {
        return res.status(404).json({ error: "No analysis found" });
      }

      res.json(analysis);
    } catch (error: any) {
      console.error("Error fetching analysis:", error);
      res.status(500).json({ error: "Failed to fetch analysis" });
    }
  });

  // Request new AI analysis
  app.post("/api/analyze", async (req, res) => {
    try {
      const { symbol, expirationDate } = req.body;
      
      if (!symbol || !expirationDate) {
        return res.status(400).json({ error: "Symbol and expiration date required" });
      }

      if (!upstoxAccessToken) {
        return res.status(401).json({ error: "Upstox not connected. Please connect first." });
      }

      // Fetch option chain from Upstox (Indian market data)
      const symbolUpper = symbol.toUpperCase();
      const instrumentKey = getInstrumentKey(symbolUpper);
      
      const optionsResponse = await axios.get(
        `https://api.upstox.com/v2/option/chain`,
        {
          params: {
            instrument_key: instrumentKey,
            expiry_date: expirationDate,
          },
          headers: {
            Authorization: `Bearer ${upstoxAccessToken}`,
            Accept: "application/json",
          },
        }
      );

      const optionData = optionsResponse.data?.data || [];
      
      // Process option chain data
      const calls: any[] = [];
      const puts: any[] = [];
      let underlyingPrice = 0;

      optionData.forEach((item: any) => {
        if (item.underlying_spot_price) {
          underlyingPrice = item.underlying_spot_price;
        }
        
        if (item.call_options?.market_data) {
          const callData = item.call_options;
          calls.push({
            strike: item.strike_price,
            ltp: callData.market_data?.ltp || 0,
            volume: callData.market_data?.volume || 0,
            oi: callData.market_data?.oi || 0,
            oiChange: callData.market_data?.oi_day_change || 0,
            iv: callData.option_greeks?.iv || 0,
          });
        }
        
        if (item.put_options?.market_data) {
          const putData = item.put_options;
          puts.push({
            strike: item.strike_price,
            ltp: putData.market_data?.ltp || 0,
            volume: putData.market_data?.volume || 0,
            oi: putData.market_data?.oi || 0,
            oiChange: putData.market_data?.oi_day_change || 0,
            iv: putData.option_greeks?.iv || 0,
          });
        }
      });

      // Calculate key metrics
      const totalCallVolume = calls.reduce((sum, c) => sum + (c.volume || 0), 0);
      const totalPutVolume = puts.reduce((sum, p) => sum + (p.volume || 0), 0);
      const totalCallOI = calls.reduce((sum, c) => sum + (c.oi || 0), 0);
      const totalPutOI = puts.reduce((sum, p) => sum + (p.oi || 0), 0);
      const pcr = totalCallOI > 0 ? (totalPutOI / totalCallOI).toFixed(2) : "N/A";
      
      // Find max OI strikes (support/resistance)
      const maxCallOI = calls.length > 0 ? calls.reduce((max, c) => c.oi > max.oi ? c : max, calls[0]) : null;
      const maxPutOI = puts.length > 0 ? puts.reduce((max, p) => p.oi > max.oi ? p : max, puts[0]) : null;
      
      // High OI change (building/unwinding)
      const callOIBuildup = calls.filter(c => c.oiChange > 0).sort((a, b) => b.oiChange - a.oiChange).slice(0, 3);
      const putOIBuildup = puts.filter(p => p.oiChange > 0).sort((a, b) => b.oiChange - a.oiChange).slice(0, 3);
      const callOIUnwinding = calls.filter(c => c.oiChange < 0).sort((a, b) => a.oiChange - b.oiChange).slice(0, 3);
      const putOIUnwinding = puts.filter(p => p.oiChange < 0).sort((a, b) => a.oiChange - b.oiChange).slice(0, 3);

      const formatINR = (num: number) => `₹${num.toLocaleString('en-IN')}`;
      const formatNum = (num: number) => num.toLocaleString('en-IN');
      
      // Get top CE/PE OI changes for analysis
      const topCEBuildup = callOIBuildup[0];
      const topCEUnwind = callOIUnwinding[0];
      const topPEBuildup = putOIBuildup[0];
      const topPEUnwind = putOIUnwinding[0];
      
      // Determine range from support/resistance
      const supportStrike = maxPutOI?.strike || 0;
      const resistanceStrike = maxCallOI?.strike || 0;

      // Calculate total OI changes for trend analysis
      const totalCEOIChange = calls.reduce((sum, c) => sum + (c.oiChange || 0), 0);
      const totalPEOIChange = puts.reduce((sum, p) => sum + (p.oiChange || 0), 0);
      
      // Get ATM strike (closest to spot)
      const atmStrike = calls.length > 0 
        ? calls.reduce((prev, curr) => 
            Math.abs(curr.strike - underlyingPrice) < Math.abs(prev.strike - underlyingPrice) ? curr : prev
          ).strike 
        : 0;
      
      // Get ATM call and put data
      const atmCall = calls.find(c => c.strike === atmStrike);
      const atmPut = puts.find(p => p.strike === atmStrike);
      
      // Find immediate support/resistance (near ATM)
      const nearCalls = calls.filter(c => c.strike >= underlyingPrice && c.strike <= underlyingPrice + 500);
      const nearPuts = puts.filter(p => p.strike <= underlyingPrice && p.strike >= underlyingPrice - 500);
      
      const immediateResistance = nearCalls.length > 0 
        ? nearCalls.reduce((max, c) => c.oi > max.oi ? c : max, nearCalls[0])?.strike 
        : resistanceStrike;
      const immediateSupport = nearPuts.length > 0 
        ? nearPuts.reduce((max, p) => p.oi > max.oi ? p : max, nearPuts[0])?.strike 
        : supportStrike;

      const prompt = `${symbolUpper} LIVE OI Analysis:

**SPOT:** ${formatINR(underlyingPrice)} | **PCR:** ${pcr}
**ATM Strike:** ${atmStrike}

**OI CHANGES TODAY:**
📈 Total CE OI Change: ${totalCEOIChange > 0 ? '+' : ''}${formatNum(totalCEOIChange)} ${totalCEOIChange > 0 ? '(Call Writers adding = Resistance building)' : '(Call Writers exiting = Resistance weak)'}
📉 Total PE OI Change: ${totalPEOIChange > 0 ? '+' : ''}${formatNum(totalPEOIChange)} ${totalPEOIChange > 0 ? '(Put Writers adding = Support building)' : '(Put Writers exiting = Support weak)'}

**KEY STRIKES:**
Max CE OI @ ${resistanceStrike} = Strong Resistance
Max PE OI @ ${supportStrike} = Strong Support
Immediate Resistance: ${immediateResistance}
Immediate Support: ${immediateSupport}

**CE ACTIVITY:**
${topCEBuildup ? `${topCEBuildup.strike} CE buildup +${formatNum(topCEBuildup.oiChange)} (writers selling = resistance)` : 'No major CE buildup'}
${topCEUnwind ? `${topCEUnwind.strike} CE unwinding ${formatNum(topCEUnwind.oiChange)} (writers covering = resistance weak)` : 'No CE unwinding'}

**PE ACTIVITY:**
${topPEBuildup ? `${topPEBuildup.strike} PE buildup +${formatNum(topPEBuildup.oiChange)} (writers selling = support)` : 'No major PE buildup'}
${topPEUnwind ? `${topPEUnwind.strike} PE unwinding ${formatNum(topPEUnwind.oiChange)} (writers covering = support weak)` : 'No PE unwinding'}

Provide analysis in this EXACT Tamil+English format:

**${immediateSupport}-${immediateResistance} RANGE**
[Bullish/Bearish/Neutral] based on PCR ${pcr}

**Call Writers என்ன பண்றாங்க:**
${topCEBuildup ? `${topCEBuildup.strike} CE-ல் +${formatNum(topCEBuildup.oiChange)} OI add` : 'No CE buildup'}
➡️ [What this means - resistance forming/breaking]

**Put Writers என்ன பண்றாங்க:**
${topPEBuildup ? `${topPEBuildup.strike} PE-ல் +${formatNum(topPEBuildup.oiChange)} OI add` : 'No PE buildup'}
➡️ [What this means - support forming/breaking]

**எந்த பக்கம் WEAK:**
Based on OI changes, identify which side is weaker (calls or puts)

**👉 இப்போது என்ன பண்ணலாம்:**
1. **CE Trade:** [Strike] CE [Buy/Sell] @ ${formatINR(atmCall?.ltp || 0)}
   - Entry: [level]
   - Target: [level] 
   - Stop Loss: [level]
   - Breakout above: [level]

2. **PE Trade:** [Strike] PE [Buy/Sell] @ ${formatINR(atmPut?.ltp || 0)}
   - Entry: [level]
   - Target: [level]
   - Stop Loss: [level]
   - Breakdown below: [level]

3. **Wait or Trade Now:** [recommendation based on momentum]

Use ➡️👉📈📉. Mix Tamil+English. Be SPECIFIC with numbers.`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `நீ ஒரு NSE/BSE F&O expert trader. Real-time OI data analyze பண்ணி actionable trade recommendations கொடுக்கணும்.

**ANALYSIS FORMAT:**

**[Support]-[Resistance] RANGE**
[Bullish/Bearish/Neutral] Zone - PCR based

**Call Writers என்ன பண்றாங்க:**
[Strike] CE-ல் OI change details
➡️ Resistance forming/breaking explanation

**Put Writers என்ன பண்றாங்க:**
[Strike] PE-ல் OI change details  
➡️ Support forming/breaking explanation

**எந்த பக்கம் WEAK:**
📉 [Call/Put] side weak because [reason]
➡️ Price likely to move [direction]

**👉 இப்போது என்ன பண்ணலாம்:**

1. **CE Trade:**
   - Strike: [number] CE
   - Action: [Buy/Sell]
   - Current Price: [₹amount]
   - Entry: Above/Below [level]
   - Target 1: [level]
   - Target 2: [level]
   - Stop Loss: [level]
   - Breakout Level: [level]

2. **PE Trade:**
   - Strike: [number] PE
   - Action: [Buy/Sell]
   - Current Price: [₹amount]
   - Entry: Above/Below [level]
   - Target 1: [level]
   - Target 2: [level]
   - Stop Loss: [level]
   - Breakdown Level: [level]

3. **Trade Now or Wait:**
   [Clear recommendation with reason]

**RULES:**
- Use SPECIFIC numbers (strikes, prices, levels)
- Mix Tamil+English naturally
- Use ➡️👉📈📉 emojis
- Focus on actionable advice
- Include risk management (SL mandatory)`
          },
          { role: "user", content: prompt }
        ],
        max_tokens: 900,
      });

      const analysisText = response.choices[0].message.content || "Analysis could not be generated.";

      // Save the analysis
      const savedAnalysis = await storage.createAnalysis({
        symbol: symbolUpper,
        expirationDate,
        analysis: analysisText,
      });

      res.json(savedAnalysis);
    } catch (error: any) {
      console.error("Error generating analysis:", error.response?.data || error.message);
      res.status(500).json({ error: "Failed to generate AI analysis", details: error.message });
    }
  });

  // Watchlist endpoints
  app.get("/api/watchlist", async (req, res) => {
    try {
      const items = await storage.getWatchlist();
      res.json(items);
    } catch (error: any) {
      console.error("Error fetching watchlist:", error);
      res.status(500).json({ error: "Failed to fetch watchlist" });
    }
  });

  app.post("/api/watchlist", async (req, res) => {
    try {
      const parsed = insertWatchlistItemSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid request body" });
      }

      const item = await storage.addToWatchlist(parsed.data);
      res.json(item);
    } catch (error: any) {
      console.error("Error adding to watchlist:", error);
      res.status(500).json({ error: "Failed to add to watchlist" });
    }
  });

  app.delete("/api/watchlist/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.removeFromWatchlist(id);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Error removing from watchlist:", error);
      res.status(500).json({ error: "Failed to remove from watchlist" });
    }
  });

  // Get quotes for all watchlist items (uses Upstox API)
  app.get("/api/watchlist/quotes", async (req, res) => {
    try {
      const items = await storage.getWatchlist();
      const quotes: Record<string, any> = {};

      if (!upstoxAccessToken) {
        // Return empty quotes if not connected
        return res.json(quotes);
      }

      // Fetch quotes from Upstox for each watchlist item
      await Promise.all(
        items.map(async (item) => {
          try {
            const instrumentKey = getInstrumentKey(item.symbol);
            const response = await axios.get(
              `https://api.upstox.com/v2/market-quote/quotes`,
              {
                params: { instrument_key: instrumentKey },
                headers: {
                  Accept: "application/json",
                  Authorization: `Bearer ${upstoxAccessToken}`,
                },
              }
            );

            const data = Object.values(response.data.data || {})[0] as any;
            if (data) {
              const changePercent = data.percentage_change || 0;
              const isBullish = changePercent >= 0.5;
              const isBearish = changePercent <= -0.5;
              
              quotes[item.symbol] = {
                symbol: item.symbol,
                shortName: data.symbol || item.symbol,
                regularMarketPrice: data.last_price || 0,
                regularMarketChange: data.net_change || 0,
                regularMarketChangePercent: changePercent,
                regularMarketVolume: data.volume || 0,
                marketCap: 0,
                trend: isBullish ? "BULLISH" : isBearish ? "BEARISH" : "NEUTRAL",
              };
            }
          } catch (e: any) {
            console.error(`Failed to fetch Upstox quote for ${item.symbol}:`, e.message);
          }
        })
      );

      res.json(quotes);
    } catch (error: any) {
      console.error("Error fetching watchlist quotes:", error);
      res.status(500).json({ error: "Failed to fetch watchlist quotes" });
    }
  });

  // ============= UPSTOX API ENDPOINTS =============

  // Get Upstox login URL for OAuth
  app.get("/api/upstox/login", (req, res) => {
    if (!UPSTOX_API_KEY) {
      return res.status(500).json({ error: "Upstox API key not configured" });
    }

    // Generate state for CSRF protection
    upstoxOAuthState = generateOAuthState();
    
    const authUrl = `https://api.upstox.com/v2/login/authorization/dialog?response_type=code&client_id=${UPSTOX_API_KEY}&redirect_uri=${encodeURIComponent(UPSTOX_REDIRECT_URI)}&state=${upstoxOAuthState}`;
    res.json({ authUrl, redirectUri: UPSTOX_REDIRECT_URI });
  });

  // OAuth callback to exchange code for access token
  app.get("/api/upstox/callback", async (req, res) => {
    try {
      const { code, state } = req.query;

      // Validate state parameter for CSRF protection
      // Allow if state matches OR if no state stored (server restarted)
      if (state && upstoxOAuthState && state !== upstoxOAuthState) {
        return res.status(400).send(`
          <html><body>
            <h1>Authorization Failed</h1>
            <p>Invalid state parameter. Please try connecting again.</p>
            <a href="/">Go back to app</a>
          </body></html>
        `);
      }

      // Clear state after validation
      upstoxOAuthState = null;

      if (!code || typeof code !== "string") {
        return res.status(400).send(`
          <html><body>
            <h1>Authorization Failed</h1>
            <p>No authorization code received.</p>
            <a href="/">Go back to app</a>
          </body></html>
        `);
      }

      if (!UPSTOX_API_KEY || !UPSTOX_API_SECRET) {
        return res.status(500).send(`
          <html><body>
            <h1>Configuration Error</h1>
            <p>Upstox API credentials not configured.</p>
          </body></html>
        `);
      }

      const tokenResponse = await axios.post(
        "https://api.upstox.com/v2/login/authorization/token",
        new URLSearchParams({
          code,
          client_id: UPSTOX_API_KEY,
          client_secret: UPSTOX_API_SECRET,
          redirect_uri: UPSTOX_REDIRECT_URI,
          grant_type: "authorization_code",
        }),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            Accept: "application/json",
          },
        }
      );

      upstoxAccessToken = tokenResponse.data.access_token;
      
      // Set expiry - Upstox tokens expire at 3:30 AM IST next day
      // If no expires_at provided, calculate default expiry
      const expiresAt = tokenResponse.data.expires_at;
      if (expiresAt) {
        upstoxTokenExpiry = new Date(parseInt(expiresAt) * 1000); // Convert from Unix timestamp
      } else {
        // Default: tokens expire at 3:30 AM IST (10 PM UTC previous day) next day
        const now = new Date();
        const expiry = new Date(now);
        expiry.setUTCHours(22, 0, 0, 0); // 3:30 AM IST = 10 PM UTC
        if (expiry <= now) {
          expiry.setUTCDate(expiry.getUTCDate() + 1);
        }
        upstoxTokenExpiry = expiry;
      }
      
      console.log("Upstox token received, expiry:", upstoxTokenExpiry?.toISOString());

      // Save token to persistent storage
      if (upstoxAccessToken && upstoxTokenExpiry) {
        await storage.saveUpstoxToken(upstoxAccessToken, upstoxTokenExpiry);
        console.log("Upstox token saved to storage for persistence");
      }

      res.send(`
        <html><body>
          <h1>Upstox Connected Successfully!</h1>
          <p>You can now access Indian market option chain data.</p>
          <script>
            setTimeout(() => { window.location.href = '/'; }, 2000);
          </script>
        </body></html>
      `);
    } catch (error: any) {
      console.error("Upstox OAuth error:", error.response?.data || error.message);
      res.status(500).send(`
        <html><body>
          <h1>Authorization Failed</h1>
          <p>${error.response?.data?.message || error.message}</p>
          <a href="/">Go back to app</a>
        </body></html>
      `);
    }
  });

  // Check Upstox connection status
  app.get("/api/upstox/status", (req, res) => {
    const isConnected = !!upstoxAccessToken;
    const isExpired = upstoxTokenExpiry ? new Date() > upstoxTokenExpiry : true;
    
    res.json({
      connected: isConnected && !isExpired,
      hasToken: isConnected,
      expiry: upstoxTokenExpiry?.toISOString() || null,
    });
  });

  // Disconnect Upstox
  app.post("/api/upstox/disconnect", async (req, res) => {
    upstoxAccessToken = null;
    upstoxTokenExpiry = null;
    await storage.clearUpstoxToken();
    console.log("Upstox disconnected and token cleared from storage");
    res.json({ success: true });
  });

  // Get Upstox option chain for Indian market
  app.get("/api/upstox/options/:symbol/:expiration", async (req, res) => {
    try {
      if (!upstoxAccessToken) {
        return res.status(401).json({ error: "Upstox not connected. Please login first." });
      }

      const { symbol, expiration } = req.params;
      const instrumentKey = getInstrumentKey(symbol);

      const response = await axios.get(
        `https://api.upstox.com/v2/option/chain`,
        {
          params: {
            instrument_key: instrumentKey,
            expiry_date: expiration,
          },
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ${upstoxAccessToken}`,
          },
        }
      );

      const data = response.data.data || [];
      
      const calls: OptionContract[] = [];
      const puts: OptionContract[] = [];
      let underlyingPrice = 0;

      // Helper to calculate change from close_price (previous day close)
      const calcChange = (ltp: number, closePrice: number): { change: number; percentChange: number } => {
        if (closePrice <= 0 || ltp <= 0) {
          return { change: 0, percentChange: 0 };
        }
        const change = ltp - closePrice;
        const percentChange = (change / closePrice) * 100;
        return { change, percentChange };
      };

      data.forEach((item: any) => {
        if (item.underlying_spot_price) {
          underlyingPrice = item.underlying_spot_price;
        }

        if (item.call_options) {
          const call = item.call_options;
          const ltp = call.market_data?.ltp || 0;
          const closePrice = call.market_data?.close_price || 0;
          const { change, percentChange } = calcChange(ltp, closePrice);
          const greeks = call.option_greeks || {};
          calls.push({
            contractSymbol: call.instrument_key || "",
            strike: item.strike_price || 0,
            lastPrice: ltp,
            bid: call.market_data?.bid_price || 0,
            ask: call.market_data?.ask_price || 0,
            change: change,
            percentChange: percentChange,
            volume: call.market_data?.volume || 0,
            openInterest: call.market_data?.oi || 0,
            oiChange: call.market_data?.oi_day_change || 0,
            impliedVolatility: greeks.iv || 0,
            inTheMoney: (item.strike_price || 0) < underlyingPrice,
            delta: greeks.delta,
            gamma: greeks.gamma,
            theta: greeks.theta,
            vega: greeks.vega,
          });
        }

        if (item.put_options) {
          const put = item.put_options;
          const ltp = put.market_data?.ltp || 0;
          const closePrice = put.market_data?.close_price || 0;
          const { change, percentChange } = calcChange(ltp, closePrice);
          const greeks = put.option_greeks || {};
          puts.push({
            contractSymbol: put.instrument_key || "",
            strike: item.strike_price || 0,
            lastPrice: ltp,
            bid: put.market_data?.bid_price || 0,
            ask: put.market_data?.ask_price || 0,
            change: change,
            percentChange: percentChange,
            volume: put.market_data?.volume || 0,
            openInterest: put.market_data?.oi || 0,
            oiChange: put.market_data?.oi_day_change || 0,
            impliedVolatility: greeks.iv || 0,
            inTheMoney: (item.strike_price || 0) > underlyingPrice,
            delta: greeks.delta,
            gamma: greeks.gamma,
            theta: greeks.theta,
            vega: greeks.vega,
          });
        }
      });

      // Sort by strike
      const sortedCalls = calls.sort((a, b) => a.strike - b.strike);
      const sortedPuts = puts.sort((a, b) => a.strike - b.strike);

      // Calculate summary metrics
      const totalCallOI = sortedCalls.reduce((sum, c) => sum + (c.openInterest || 0), 0);
      const totalPutOI = sortedPuts.reduce((sum, p) => sum + (p.openInterest || 0), 0);
      const pcr = totalCallOI > 0 ? totalPutOI / totalCallOI : 0;

      // Calculate CE and PE buildup (sum of positive OI changes)
      const ceBuildup = sortedCalls.reduce((sum, c) => sum + Math.max(0, c.oiChange || 0), 0);
      const peBuildup = sortedPuts.reduce((sum, p) => sum + Math.max(0, p.oiChange || 0), 0);

      // Determine trend direction
      let trendDirection: "CE_BUILDUP" | "PE_BUILDUP" | "NEUTRAL" = "NEUTRAL";
      if (ceBuildup > peBuildup * 1.2) {
        trendDirection = "CE_BUILDUP";
      } else if (peBuildup > ceBuildup * 1.2) {
        trendDirection = "PE_BUILDUP";
      }

      // Find ATM strike
      const strikeSet = new Set<number>();
      sortedCalls.forEach(c => strikeSet.add(c.strike));
      sortedPuts.forEach(p => strikeSet.add(p.strike));
      const allStrikes = Array.from(strikeSet).sort((a, b) => a - b);
      const atmStrike = allStrikes.reduce((prev, curr) => 
        Math.abs(curr - underlyingPrice) < Math.abs(prev - underlyingPrice) ? curr : prev
      , allStrikes[0] || 0);

      // Calculate Max Pain (strike with maximum combined OI)
      const strikeOIMap = new Map<number, number>();
      sortedCalls.forEach(c => {
        const current = strikeOIMap.get(c.strike) || 0;
        strikeOIMap.set(c.strike, current + (c.openInterest || 0));
      });
      sortedPuts.forEach(p => {
        const current = strikeOIMap.get(p.strike) || 0;
        strikeOIMap.set(p.strike, current + (p.openInterest || 0));
      });
      
      let maxPain = atmStrike;
      let maxOI = 0;
      strikeOIMap.forEach((oi, strike) => {
        if (oi > maxOI) {
          maxOI = oi;
          maxPain = strike;
        }
      });

      const summary = {
        spotPrice: underlyingPrice,
        maxPain,
        pcr,
        totalCallOI,
        totalPutOI,
        ceBuildup,
        peBuildup,
        trendDirection,
        atmStrike,
      };

      const optionChainData: OptionChainData = {
        symbol: symbol.toUpperCase(),
        underlyingPrice,
        expirationDates: [],
        selectedExpiration: expiration,
        calls: sortedCalls,
        puts: sortedPuts,
        summary,
        lastUpdated: new Date().toISOString(),
      };

      res.json(optionChainData);
    } catch (error: any) {
      console.error("Upstox option chain error:", error.response?.data || error.message);
      if (error.response?.status === 401) {
        upstoxAccessToken = null;
        return res.status(401).json({ error: "Upstox session expired. Please login again." });
      }
      res.status(500).json({ error: "Failed to fetch Indian option chain" });
    }
  });

  // Get Upstox expiration dates
  app.get("/api/upstox/expirations/:symbol", async (req, res) => {
    try {
      if (!upstoxAccessToken) {
        return res.status(401).json({ error: "Upstox not connected. Please login first." });
      }

      const { symbol } = req.params;
      const instrumentKey = getInstrumentKey(symbol);

      const response = await axios.get(
        `https://api.upstox.com/v2/option/contract`,
        {
          params: {
            instrument_key: instrumentKey,
          },
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ${upstoxAccessToken}`,
          },
        }
      );

      const contracts = response.data.data || [];
      const expirationSet = new Set<string>();
      
      contracts.forEach((contract: any) => {
        if (contract.expiry) {
          expirationSet.add(contract.expiry);
        }
      });

      const expirationDates = Array.from(expirationSet).sort();
      res.json({ expirationDates });
    } catch (error: any) {
      console.error("Upstox expirations error:", error.response?.data || error.message);
      if (error.response?.status === 401) {
        upstoxAccessToken = null;
        return res.status(401).json({ error: "Upstox session expired. Please login again." });
      }
      res.status(500).json({ error: "Failed to fetch expiration dates" });
    }
  });

  // Get Upstox quote for Indian stock/index
  app.get("/api/upstox/quote/:symbol", async (req, res) => {
    try {
      if (!upstoxAccessToken) {
        return res.status(401).json({ error: "Upstox not connected. Please login first." });
      }

      const { symbol } = req.params;
      const instrumentKey = getInstrumentKey(symbol);

      const response = await axios.get(
        `https://api.upstox.com/v2/market-quote/quotes`,
        {
          params: {
            instrument_key: instrumentKey,
          },
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ${upstoxAccessToken}`,
          },
        }
      );

      const data = Object.values(response.data.data || {})[0] as any;
      
      if (!data) {
        return res.status(404).json({ error: "Stock not found" });
      }

      // Extract OHLC data from Upstox response
      const ohlc = data.ohlc || {};
      
      // Get proper name for indices
      const getDisplayName = (sym: string) => {
        const names: Record<string, string> = {
          "NIFTY": "Nifty 50",
          "BANKNIFTY": "Bank Nifty", 
          "FINNIFTY": "Fin Nifty",
          "MIDCPNIFTY": "Midcap Nifty",
          "SENSEX": "BSE Sensex",
        };
        return names[sym.toUpperCase()] || data.short_name || data.symbol || sym;
      };

      // Extract values with proper fallbacks
      const lastPrice = data.last_price || 0;
      // Previous close = yesterday's close, use OHLC close as fallback
      const prevClose = ohlc.close || data.close_price || 0;
      // Net change from API or calculate from prices
      const netChange = data.net_change !== undefined ? data.net_change : (lastPrice - prevClose);
      // Calculate percentage change from net_change and previous close
      const pctChange = prevClose > 0 ? ((netChange / prevClose) * 100) : 0;

      // Circuit limits as approximate 52W bounds (Upstox doesn't provide actual 52W data)
      const upperCircuit = data.upper_circuit_limit || 0;
      const lowerCircuit = data.lower_circuit_limit || 0;

      // Volume from API
      const volume = data.volume || 0;
      
      // Timestamp for last update
      const timestamp = data.timestamp || new Date().toISOString();
      
      const stockQuote: StockQuote = {
        symbol: symbol.toUpperCase(),
        shortName: getDisplayName(symbol),
        regularMarketPrice: lastPrice,
        regularMarketChange: netChange,
        regularMarketChangePercent: pctChange,
        regularMarketVolume: volume,
        marketCap: 0,
        open: ohlc.open || 0,
        high: ohlc.high || 0,
        low: ohlc.low || 0,
        close: ohlc.close || lastPrice || 0,
        previousClose: prevClose,
        yearHigh: upperCircuit,  // Using circuit limit as approx
        yearLow: lowerCircuit,   // Using circuit limit as approx
        timestamp: timestamp,
      };

      res.json(stockQuote);
    } catch (error: any) {
      console.error("Upstox quote error:", error.response?.data || error.message);
      if (error.response?.status === 401) {
        upstoxAccessToken = null;
        return res.status(401).json({ error: "Upstox session expired. Please login again." });
      }
      res.status(500).json({ error: "Failed to fetch stock quote" });
    }
  });

  // Get historical candle data for chart
  app.get("/api/upstox/candles/:symbol", async (req, res) => {
    try {
      if (!upstoxAccessToken) {
        return res.status(401).json({ error: "Upstox not connected. Please login first." });
      }

      const { symbol } = req.params;
      const instrumentKey = getInstrumentKey(symbol);
      
      // Get last 30 days of daily candles
      const toDate = new Date();
      const fromDate = new Date();
      fromDate.setDate(fromDate.getDate() - 30);
      
      const formatDate = (d: Date) => d.toISOString().split('T')[0];

      const response = await axios.get(
        `https://api.upstox.com/v2/historical-candle/${encodeURIComponent(instrumentKey)}/day/${formatDate(toDate)}/${formatDate(fromDate)}`,
        {
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ${upstoxAccessToken}`,
          },
        }
      );

      const candleData = response.data.data?.candles || [];
      
      // Transform Upstox candle format: [timestamp, open, high, low, close, volume, oi]
      const candles = candleData.map((candle: any[]) => ({
        date: new Date(candle[0]).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }),
        open: candle[1],
        high: candle[2],
        low: candle[3],
        close: candle[4],
        volume: candle[5],
      })).reverse(); // Reverse to show oldest first

      res.json({ candles });
    } catch (error: any) {
      console.error("Upstox candles error:", error.response?.data || error.message);
      if (error.response?.status === 401) {
        upstoxAccessToken = null;
        return res.status(401).json({ error: "Upstox session expired. Please login again." });
      }
      res.status(500).json({ error: "Failed to fetch candle data", candles: [] });
    }
  });

  // WebSocket server setup for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });

  wss.on("connection", (ws) => {
    console.log("WebSocket client connected");
    wsClients.add(ws);

    ws.on("close", () => {
      console.log("WebSocket client disconnected");
      wsClients.delete(ws);
    });

    ws.on("error", (error) => {
      console.error("WebSocket error:", error);
      wsClients.delete(ws);
    });

    // Send initial connection success
    ws.send(JSON.stringify({ type: "connected", message: "Real-time updates enabled" }));
  });

  // Background price monitoring for watchlist with rate limiting
  let priceMonitorInterval: NodeJS.Timeout | null = null;
  let isMonitorRunning = false;

  async function monitorWatchlistPrices() {
    if (!upstoxAccessToken || wsClients.size === 0 || isMonitorRunning) return;

    isMonitorRunning = true;
    
    try {
      const watchlist = await storage.getWatchlist();
      if (!watchlist || watchlist.length === 0) {
        isMonitorRunning = false;
        return;
      }

      // Batch symbols into groups of 5 to respect rate limits
      const BATCH_SIZE = 5;
      const BATCH_DELAY = 1000; // 1 second between batches

      for (let i = 0; i < watchlist.length; i += BATCH_SIZE) {
        const batch = watchlist.slice(i, i + BATCH_SIZE);
        
        // Build comma-separated instrument keys for batch request
        const instrumentKeys = batch
          .map(item => getUpstoxInstrumentKey(item.symbol))
          .filter(Boolean)
          .join(",");

        if (!instrumentKeys) continue;

        try {
          const response = await axios.get(
            `https://api.upstox.com/v2/market-quote/quotes?instrument_key=${encodeURIComponent(instrumentKeys)}`,
            {
              headers: {
                Authorization: `Bearer ${upstoxAccessToken}`,
                Accept: "application/json",
              },
              timeout: 10000, // 10 second timeout
            }
          );

          const quotes = response.data?.data || {};
          
          for (const [key, data] of Object.entries(quotes)) {
            const stockData = data as any;
            if (!stockData) continue;

            // Extract symbol from the response
            const symbol = batch.find(item => {
              const instrKey = getUpstoxInstrumentKey(item.symbol);
              return instrKey && key.includes(instrKey.split("|")[1]);
            })?.symbol;

            if (!symbol) continue;

            const currentPrice = stockData.last_price || 0;
            const previousPrice = lastPrices.get(symbol);
            const change = stockData.net_change || 0;
            const changePercent = stockData.percentage_change || 0;

            // Check if price changed significantly (more than 0.1%)
            if (previousPrice && Math.abs((currentPrice - previousPrice) / previousPrice) > 0.001) {
              broadcast({
                type: "price_update",
                symbol: symbol,
                price: currentPrice,
                change: change,
                changePercent: changePercent,
                previousPrice: previousPrice,
                timestamp: new Date().toISOString(),
              });
            }

            lastPrices.set(symbol, currentPrice);
          }
        } catch (err: any) {
          // Log rate limit errors specifically
          if (err.response?.status === 429) {
            console.warn("Upstox rate limit hit, slowing down requests");
            await new Promise(resolve => setTimeout(resolve, 5000)); // Wait 5 seconds
          }
        }

        // Add delay between batches to respect rate limits
        if (i + BATCH_SIZE < watchlist.length) {
          await new Promise(resolve => setTimeout(resolve, BATCH_DELAY));
        }
      }
    } catch (error) {
      console.error("Price monitor error:", error);
    } finally {
      isMonitorRunning = false;
    }
  }

  // Start price monitoring every 15 seconds (more conservative)
  priceMonitorInterval = setInterval(monitorWatchlistPrices, 15000);

  // Helper function to get instrument key
  function getUpstoxInstrumentKey(symbol: string): string | null {
    const upperSymbol = symbol.toUpperCase();
    if (INDIAN_INDICES[upperSymbol]) {
      return INDIAN_INDICES[upperSymbol];
    }
    if (NSE_STOCKS[upperSymbol]) {
      return `NSE_EQ|${NSE_STOCKS[upperSymbol]}`;
    }
    return null;
  }

  // ============= CHAT API ENDPOINTS =============

  // Get or create conversation and its history
  app.get("/api/chat/:symbol/:expiration", async (req, res) => {
    try {
      const { symbol, expiration } = req.params;
      const conversation = await storage.getOrCreateConversation(symbol, expiration);
      const messages = await storage.getConversationMessages(conversation.id, 20);
      res.json({ conversation, messages });
    } catch (error: any) {
      console.error("Error fetching chat:", error);
      res.status(500).json({ error: "Failed to fetch chat" });
    }
  });

  // Send chat message and get AI response
  app.post("/api/chat/send", async (req, res) => {
    try {
      const { symbol, expirationDate, message } = req.body;
      
      if (!symbol || !expirationDate || !message) {
        return res.status(400).json({ error: "Symbol, expiration date and message required" });
      }

      // Get or create conversation
      const conversation = await storage.getOrCreateConversation(symbol, expirationDate);
      
      // Save user message
      const userMessage = await storage.addChatMessage({
        conversationId: conversation.id,
        role: "user",
        content: message,
      });

      // Get last few messages for context
      const history = await storage.getConversationMessages(conversation.id, 10);
      
      // Get latest analysis for context if exists
      const analysis = await storage.getLatestAnalysis(symbol, expirationDate);
      
      // Build context for AI
      let systemContext = `நீ ஒரு NSE/BSE F&O trading expert. User stock options பற்றி கேள்வி கேட்கிறார்.

Symbol: ${symbol.toUpperCase()}
Expiry: ${expirationDate}
${analysis ? `\nLatest AI Analysis:\n${analysis.analysis}` : ''}

Rules:
- Tamil + English கலந்து பதில் கொடு (user Tamil speaker)
- Keep responses SHORT and actionable (max 150 words)
- Use simple trading terms
- Focus on support/resistance, OI changes, PCR interpretation
- ALWAYS include "என்ன பண்ணலாம்" (what to do) suggestions:
  - Which CE/PE to buy/sell
  - Entry levels
  - Stop loss levels
  - Target levels
- Use emojis like ➡️👉📈📉 for clarity
- If user just says வணக்கம் or asks for summary, explain the current option data and give specific trade suggestions`;

      // Build messages array for OpenAI
      const openaiMessages: any[] = [
        { role: "system", content: systemContext },
      ];

      // Add conversation history
      history.slice(-6).forEach((msg) => {
        openaiMessages.push({
          role: msg.role === "user" ? "user" : "assistant",
          content: msg.content,
        });
      });

      // Call OpenAI
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: openaiMessages,
        max_tokens: 300,
      });

      const aiResponse = response.choices[0].message.content || "பதில் generate ஆகவில்லை.";

      // Save AI response
      const assistantMessage = await storage.addChatMessage({
        conversationId: conversation.id,
        role: "assistant",
        content: aiResponse,
      });

      res.json({
        userMessage,
        assistantMessage,
      });
    } catch (error: any) {
      console.error("Error in chat:", error);
      res.status(500).json({ error: "Failed to process chat", details: error.message });
    }
  });

  // Clear chat history for a conversation
  app.delete("/api/chat/:symbol/:expiration", async (req, res) => {
    try {
      const { symbol, expiration } = req.params;
      // For now, we don't delete - just acknowledge
      // Could implement full deletion if needed
      res.json({ success: true });
    } catch (error: any) {
      console.error("Error clearing chat:", error);
      res.status(500).json({ error: "Failed to clear chat" });
    }
  });

  return httpServer;
}
