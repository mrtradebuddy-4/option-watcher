import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { BarChart3, TrendingUp, TrendingDown, X } from "lucide-react";
import {
  ComposedChart,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Bar,
  Cell,
  ReferenceLine,
} from "recharts";

interface CandlestickData {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

interface CandlestickChartProps {
  symbol: string;
  isOpen: boolean;
  onClose: () => void;
  currentPrice?: number;
}

export function CandlestickChart({ symbol, isOpen, onClose, currentPrice }: CandlestickChartProps) {
  const { data: chartData, isLoading } = useQuery<{ candles: CandlestickData[] }>({
    queryKey: ["/api/upstox/candles", symbol],
    enabled: isOpen && !!symbol,
  });

  const candles = chartData?.candles || [];
  
  // Calculate chart data with OHLC bars
  const processedData = candles.map((candle, index) => {
    const isGreen = candle.close >= candle.open;
    return {
      ...candle,
      index,
      isGreen,
      // For candlestick visualization
      bodyBottom: Math.min(candle.open, candle.close),
      bodyTop: Math.max(candle.open, candle.close),
      bodyHeight: Math.abs(candle.close - candle.open),
      wickHigh: candle.high,
      wickLow: candle.low,
    };
  });

  // Calculate price range for Y axis
  const allPrices = candles.flatMap(c => [c.high, c.low]);
  const minPrice = Math.min(...allPrices) * 0.998;
  const maxPrice = Math.max(...allPrices) * 1.002;

  // Calculate trend
  const firstClose = candles[0]?.close || 0;
  const lastClose = candles[candles.length - 1]?.close || 0;
  const trendPercent = firstClose ? ((lastClose - firstClose) / firstClose * 100) : 0;
  const isUpTrend = trendPercent >= 0;

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      minimumFractionDigits: 2,
    }).format(price);
  };

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-popover border rounded-md p-2 shadow-lg text-xs">
          <p className="font-medium mb-1">{data.date}</p>
          <div className="grid grid-cols-2 gap-x-3 gap-y-0.5">
            <span className="text-muted-foreground">Open:</span>
            <span>{formatPrice(data.open)}</span>
            <span className="text-muted-foreground">High:</span>
            <span className="text-green-500">{formatPrice(data.high)}</span>
            <span className="text-muted-foreground">Low:</span>
            <span className="text-red-500">{formatPrice(data.low)}</span>
            <span className="text-muted-foreground">Close:</span>
            <span className={data.isGreen ? "text-green-500" : "text-red-500"}>
              {formatPrice(data.close)}
            </span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-3xl max-h-[90vh] p-0">
        <DialogHeader className="p-4 pb-2 border-b">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <DialogTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" />
                {symbol} Price Chart
              </DialogTitle>
              {candles.length > 0 && (
                <Badge 
                  variant={isUpTrend ? "default" : "destructive"}
                  className={`text-xs ${isUpTrend ? "bg-green-600" : "bg-red-600"}`}
                >
                  {isUpTrend ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
                  {trendPercent >= 0 ? "+" : ""}{trendPercent.toFixed(2)}%
                </Badge>
              )}
            </div>
            <Button size="icon" variant="ghost" onClick={onClose} data-testid="button-close-chart">
              <X className="h-4 w-4" />
            </Button>
          </div>
          {currentPrice && (
            <p className="text-sm text-muted-foreground">
              Current: {formatPrice(currentPrice)}
            </p>
          )}
        </DialogHeader>
        
        <div className="p-4">
          {isLoading ? (
            <div className="space-y-2">
              <Skeleton className="h-[300px] w-full" />
            </div>
          ) : candles.length === 0 ? (
            <div className="h-[300px] flex items-center justify-center text-muted-foreground">
              No chart data available for {symbol}
            </div>
          ) : (
            <div className="h-[350px]">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={processedData} margin={{ top: 10, right: 10, left: 0, bottom: 10 }}>
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 10 }}
                    tickLine={false}
                    axisLine={{ stroke: 'hsl(var(--border))' }}
                    interval="preserveStartEnd"
                  />
                  <YAxis 
                    domain={[minPrice, maxPrice]}
                    tick={{ fontSize: 10 }}
                    tickLine={false}
                    axisLine={{ stroke: 'hsl(var(--border))' }}
                    tickFormatter={(val) => val.toLocaleString("en-IN")}
                    width={70}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  
                  {currentPrice && (
                    <ReferenceLine 
                      y={currentPrice} 
                      stroke="hsl(var(--primary))" 
                      strokeDasharray="3 3"
                      label={{ 
                        value: `LTP: ${currentPrice.toLocaleString("en-IN")}`,
                        position: "right",
                        fill: "hsl(var(--primary))",
                        fontSize: 10
                      }}
                    />
                  )}

                  {/* Wicks (High-Low lines) */}
                  {processedData.map((entry, index) => (
                    <ReferenceLine
                      key={`wick-${index}`}
                      segment={[
                        { x: entry.date, y: entry.wickLow },
                        { x: entry.date, y: entry.wickHigh }
                      ]}
                      stroke={entry.isGreen ? "#22c55e" : "#ef4444"}
                      strokeWidth={1}
                    />
                  ))}

                  {/* Candle Bodies */}
                  <Bar dataKey="bodyHeight" stackId="candle" barSize={8}>
                    {processedData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`}
                        fill={entry.isGreen ? "#22c55e" : "#ef4444"}
                      />
                    ))}
                  </Bar>
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          )}
          
          <div className="flex items-center justify-center gap-4 mt-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <span className="w-3 h-3 bg-green-500 rounded-sm" /> Bullish
            </span>
            <span className="flex items-center gap-1">
              <span className="w-3 h-3 bg-red-500 rounded-sm" /> Bearish
            </span>
            <span>Last 30 Days</span>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
