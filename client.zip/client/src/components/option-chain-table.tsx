import { useEffect, useRef, useState, Fragment, useMemo } from "react";
import type { OptionContract, OptionChainSummary } from "@shared/schema";
import { TrendingUp, TrendingDown, ArrowUp, ArrowDown, Activity, Target, BarChart2, ArrowUpDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface OptionChainTableProps {
  calls: OptionContract[];
  puts: OptionContract[];
  underlyingPrice: number;
  summary?: OptionChainSummary;
}

type SortField = "oi" | "ltp" | "change" | "none";
type SortDirection = "asc" | "desc";

export function OptionChainTable({ calls, puts, underlyingPrice, summary }: OptionChainTableProps) {
  const spotRowRef = useRef<HTMLTableRowElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [sortField, setSortField] = useState<SortField>("none");
  const [sortDirection, setSortDirection] = useState<SortDirection>("desc");

  const formatNumber = (num: number | undefined, decimals: number = 2) => {
    if (num === undefined || num === null || num === 0) return "-";
    return num.toLocaleString("en-IN", { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  };

  const formatOI = (oi: number | undefined) => {
    if (!oi || oi === 0) return "-";
    if (oi >= 10000000) return (oi / 10000000).toFixed(2) + " Cr";
    if (oi >= 100000) return (oi / 100000).toFixed(2) + " L";
    if (oi >= 1000) return (oi / 1000).toFixed(1) + " K";
    return oi.toLocaleString("en-IN");
  };

  const formatOIChangePercent = (current: number | undefined, change: number | undefined) => {
    if (!current || current === 0 || change === undefined) return "-";
    const percent = (change / (current - change)) * 100;
    if (!isFinite(percent)) return "-";
    const sign = percent > 0 ? "+" : "";
    return sign + percent.toFixed(1) + "%";
  };

  const formatPrice = (price: number | undefined) => {
    if (!price || price === 0) return "-";
    return price.toFixed(2);
  };

  const formatVolume = (vol: number | undefined) => {
    if (!vol || vol === 0) return "-";
    if (vol >= 100000) return (vol / 100000).toFixed(1) + "L";
    if (vol >= 1000) return (vol / 1000).toFixed(1) + "K";
    return vol.toLocaleString("en-IN");
  };

  const formatIV = (iv: number | undefined) => {
    if (!iv) return "-";
    return (iv * 100).toFixed(1) + "%";
  };

  const formatChange = (change: number | undefined) => {
    if (change === undefined || change === null) return "-";
    const sign = change > 0 ? "+" : "";
    return sign + change.toFixed(2);
  };

  const formatBidAsk = (bid: number | undefined, ask: number | undefined) => {
    const b = bid ? bid.toFixed(1) : "-";
    const a = ask ? ask.toFixed(1) : "-";
    return `${b}/${a}`;
  };

  const strikes = useMemo(() => 
    Array.from(new Set([...calls.map(c => c.strike), ...puts.map(p => p.strike)])).sort((a, b) => a - b),
    [calls, puts]
  );
  
  const callMap = useMemo(() => new Map(calls.map(c => [c.strike, c])), [calls]);
  const putMap = useMemo(() => new Map(puts.map(p => [p.strike, p])), [puts]);

  const totalCallOI = useMemo(() => calls.reduce((sum, c) => sum + (c.openInterest || 0), 0), [calls]);
  const totalPutOI = useMemo(() => puts.reduce((sum, p) => sum + (p.openInterest || 0), 0), [puts]);
  const calculatedPCR = totalCallOI > 0 ? totalPutOI / totalCallOI : 0;
  
  const calculatedAtmStrike = useMemo(() => {
    if (strikes.length === 0) return 0;
    return strikes.reduce((prev, curr) => 
      Math.abs(curr - underlyingPrice) < Math.abs(prev - underlyingPrice) ? curr : prev
    , strikes[0]);
  }, [strikes, underlyingPrice]);
  
  const calculateMaxPain = useMemo(() => {
    let minPain = Infinity;
    let maxPainStrike = calculatedAtmStrike;
    for (const strike of strikes) {
      let pain = 0;
      calls.forEach(c => {
        if (strike > c.strike) pain += (strike - c.strike) * (c.openInterest || 0);
      });
      puts.forEach(p => {
        if (strike < p.strike) pain += (p.strike - strike) * (p.openInterest || 0);
      });
      if (pain < minPain) {
        minPain = pain;
        maxPainStrike = strike;
      }
    }
    return maxPainStrike;
  }, [strikes, calls, puts, calculatedAtmStrike]);
  
  const effectiveSummary: OptionChainSummary = summary || {
    spotPrice: underlyingPrice,
    maxPain: calculateMaxPain,
    pcr: calculatedPCR,
    totalCallOI,
    totalPutOI,
    ceBuildup: 0,
    peBuildup: 0,
    trendDirection: calculatedPCR > 1.2 ? "PE_BUILDUP" : calculatedPCR < 0.7 ? "CE_BUILDUP" : "NEUTRAL",
    atmStrike: calculatedAtmStrike,
  };

  const atmStrike = effectiveSummary.atmStrike;
  const atmIndex = strikes.indexOf(atmStrike);
  const startIndex = Math.max(0, atmIndex - 15);
  const endIndex = Math.min(strikes.length, atmIndex + 16);
  
  const visibleStrikes = useMemo(() => {
    let strikesToShow = strikes.slice(startIndex, endIndex);
    
    if (sortField !== "none") {
      strikesToShow = [...strikesToShow].sort((a, b) => {
        const callA = callMap.get(a);
        const callB = callMap.get(b);
        const putA = putMap.get(a);
        const putB = putMap.get(b);
        
        let valA = 0, valB = 0;
        
        if (sortField === "oi") {
          valA = Math.max(callA?.openInterest || 0, putA?.openInterest || 0);
          valB = Math.max(callB?.openInterest || 0, putB?.openInterest || 0);
        } else if (sortField === "ltp") {
          valA = Math.max(callA?.lastPrice || 0, putA?.lastPrice || 0);
          valB = Math.max(callB?.lastPrice || 0, putB?.lastPrice || 0);
        } else if (sortField === "change") {
          valA = Math.max(Math.abs(callA?.percentChange || 0), Math.abs(putA?.percentChange || 0));
          valB = Math.max(Math.abs(callB?.percentChange || 0), Math.abs(putB?.percentChange || 0));
        }
        
        return sortDirection === "desc" ? valB - valA : valA - valB;
      });
    }
    
    return strikesToShow;
  }, [strikes, startIndex, endIndex, sortField, sortDirection, callMap, putMap]);

  const maxCallOI = useMemo(() => Math.max(...calls.map(c => c.openInterest || 0), 1), [calls]);
  const maxPutOI = useMemo(() => Math.max(...puts.map(p => p.openInterest || 0), 1), [puts]);

  const getOIBarWidth = (oi: number | undefined, maxOI: number) => {
    if (!oi || maxOI === 0) return 0;
    return Math.min((oi / maxOI) * 100, 100);
  };

  useEffect(() => {
    if (spotRowRef.current && sortField === "none") {
      spotRowRef.current.scrollIntoView({ block: "center", behavior: "auto" });
    }
  }, [underlyingPrice, sortField]);

  const getChangeColor = (change: number | undefined) => {
    if (change === undefined || change === null || change === 0) return "text-slate-400 dark:text-slate-500";
    return change > 0 ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400";
  };

  const getChangeBg = (change: number | undefined) => {
    if (change === undefined || change === null || change === 0) return "";
    return change > 0 ? "bg-green-500/10" : "bg-red-500/10";
  };

  const getPCRColor = (pcr: number) => {
    if (pcr > 1.2) return "text-green-500";
    if (pcr > 1) return "text-green-400";
    if (pcr < 0.7) return "text-red-500";
    if (pcr < 1) return "text-red-400";
    return "text-amber-500";
  };

  const getTrendBadge = () => {
    const { trendDirection } = effectiveSummary;
    
    if (trendDirection === "CE_BUILDUP") {
      return (
        <Badge className="bg-red-600 text-white text-xs font-semibold px-3 py-1">
          <TrendingDown className="h-3.5 w-3.5 mr-1" />
          Bearish
        </Badge>
      );
    }
    if (trendDirection === "PE_BUILDUP") {
      return (
        <Badge className="bg-green-600 text-white text-xs font-semibold px-3 py-1">
          <TrendingUp className="h-3.5 w-3.5 mr-1" />
          Bullish
        </Badge>
      );
    }
    return (
      <Badge className="bg-amber-600 text-white text-xs font-semibold px-3 py-1">
        Neutral
      </Badge>
    );
  };

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      if (sortDirection === "desc") {
        setSortDirection("asc");
      } else {
        setSortField("none");
      }
    } else {
      setSortField(field);
      setSortDirection("desc");
    }
  };

  const spotInsertIndex = visibleStrikes.findIndex(s => s >= underlyingPrice);

  const cellClass = "px-2 py-2.5 text-xs font-medium text-right whitespace-nowrap";
  const headerClass = "px-2 py-2 text-[11px] font-bold text-center whitespace-nowrap uppercase tracking-wide";

  return (
    <div className="w-full border border-slate-300 dark:border-slate-700 rounded-lg overflow-hidden bg-white dark:bg-slate-900" data-testid="option-chain-table">
      {/* Spot Price Bar - Bold and prominent */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 dark:from-blue-700 dark:to-blue-800 px-4 py-3">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-6">
            <div className="flex items-center gap-2">
              <Activity className="h-5 w-5 text-white" />
              <span className="text-white/80 text-sm font-medium">SPOT</span>
              <span className="text-white text-xl font-bold font-mono" data-testid="text-spot-price">
                {effectiveSummary.spotPrice.toLocaleString("en-IN", { minimumFractionDigits: 2 })}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Target className="h-4 w-4 text-purple-300" />
              <span className="text-white/80 text-sm">Max Pain:</span>
              <span className="text-white font-bold font-mono" data-testid="text-max-pain">
                {effectiveSummary.maxPain.toLocaleString("en-IN")}
              </span>
            </div>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center gap-2 cursor-help">
                  <BarChart2 className="h-4 w-4 text-amber-300" />
                  <span className="text-white/80 text-sm">PCR:</span>
                  <span className={`font-bold font-mono ${effectiveSummary.pcr > 1 ? "text-green-300" : effectiveSummary.pcr < 0.8 ? "text-red-300" : "text-amber-300"}`} data-testid="text-pcr">
                    {effectiveSummary.pcr.toFixed(2)}
                  </span>
                </div>
              </TooltipTrigger>
              <TooltipContent side="bottom" className="text-xs bg-slate-800 text-white border-slate-700">
                <div className="space-y-1">
                  <div>Call OI: {formatOI(effectiveSummary.totalCallOI)}</div>
                  <div>Put OI: {formatOI(effectiveSummary.totalPutOI)}</div>
                  <div className="pt-1 border-t border-slate-600">
                    {effectiveSummary.pcr > 1.2 ? "Strong Bullish" : 
                     effectiveSummary.pcr > 1 ? "Mild Bullish" :
                     effectiveSummary.pcr < 0.7 ? "Strong Bearish" :
                     effectiveSummary.pcr < 1 ? "Mild Bearish" : "Neutral"}
                  </div>
                </div>
              </TooltipContent>
            </Tooltip>
          </div>
          <div className="flex items-center gap-3">
            {getTrendBadge()}
            <Select value={sortField} onValueChange={(v) => handleSort(v as SortField)}>
              <SelectTrigger className="w-28 h-8 bg-white/10 border-white/20 text-white text-xs" data-testid="select-sort">
                <ArrowUpDown className="h-3 w-3 mr-1" />
                <SelectValue placeholder="Sort" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Default</SelectItem>
                <SelectItem value="oi">By OI</SelectItem>
                <SelectItem value="ltp">By LTP</SelectItem>
                <SelectItem value="change">By Change</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <div ref={containerRef} className="overflow-x-auto">
        <table className="w-full border-collapse" style={{ minWidth: "1000px" }}>
          <thead className="sticky top-0 z-20">
            <tr className="bg-slate-100 dark:bg-slate-800">
              <th colSpan={8} className="py-2 text-center border-b-2 border-r-2 border-slate-300 dark:border-slate-600">
                <span className="text-sm font-bold text-red-600 dark:text-red-400 tracking-wider">CALLS (CE)</span>
              </th>
              <th className="py-2 text-center border-b-2 border-r-2 border-slate-300 dark:border-slate-600 bg-slate-200 dark:bg-slate-700">
                <span className="text-sm font-bold text-slate-700 dark:text-slate-200">STRIKE</span>
              </th>
              <th colSpan={8} className="py-2 text-center border-b-2 border-slate-300 dark:border-slate-600">
                <span className="text-sm font-bold text-green-600 dark:text-green-400 tracking-wider">PUTS (PE)</span>
              </th>
            </tr>
            <tr className="bg-slate-50 dark:bg-slate-850 text-slate-600 dark:text-slate-400">
              <th className={`${headerClass} border-b border-r border-slate-200 dark:border-slate-700 text-red-600 dark:text-red-400`}>OI Bar</th>
              <th className={`${headerClass} border-b border-r border-slate-200 dark:border-slate-700`}>OI</th>
              <th className={`${headerClass} border-b border-r border-slate-200 dark:border-slate-700`}>OI Chg%</th>
              <th className={`${headerClass} border-b border-r border-slate-200 dark:border-slate-700`}>Vol</th>
              <th className={`${headerClass} border-b border-r border-slate-200 dark:border-slate-700`}>IV</th>
              <th className={`${headerClass} border-b border-r border-slate-200 dark:border-slate-700 text-red-600 dark:text-red-400`}>LTP</th>
              <th className={`${headerClass} border-b border-r border-slate-200 dark:border-slate-700`}>Chg</th>
              <th className={`${headerClass} border-b border-r-2 border-slate-300 dark:border-slate-600`}>Bid/Ask</th>
              <th className={`${headerClass} border-b border-r-2 border-slate-300 dark:border-slate-600 bg-slate-100 dark:bg-slate-700 text-slate-800 dark:text-slate-200`}>Strike</th>
              <th className={`${headerClass} border-b border-r border-slate-200 dark:border-slate-700`}>Bid/Ask</th>
              <th className={`${headerClass} border-b border-r border-slate-200 dark:border-slate-700`}>Chg</th>
              <th className={`${headerClass} border-b border-r border-slate-200 dark:border-slate-700 text-green-600 dark:text-green-400`}>LTP</th>
              <th className={`${headerClass} border-b border-r border-slate-200 dark:border-slate-700`}>IV</th>
              <th className={`${headerClass} border-b border-r border-slate-200 dark:border-slate-700`}>Vol</th>
              <th className={`${headerClass} border-b border-r border-slate-200 dark:border-slate-700`}>OI Chg%</th>
              <th className={`${headerClass} border-b border-r border-slate-200 dark:border-slate-700`}>OI</th>
              <th className={`${headerClass} border-b border-slate-200 dark:border-slate-700 text-green-600 dark:text-green-400`}>OI Bar</th>
            </tr>
          </thead>
          <tbody>
            {visibleStrikes.map((strike, index) => {
              const call = callMap.get(strike);
              const put = putMap.get(strike);
              const isITMCall = strike < underlyingPrice;
              const isITMPut = strike > underlyingPrice;
              const isATM = strike === atmStrike;
              const isAtSpot = sortField === "none" && index === spotInsertIndex;

              const callOIBar = getOIBarWidth(call?.openInterest, maxCallOI);
              const putOIBar = getOIBarWidth(put?.openInterest, maxPutOI);

              const rowBg = isATM 
                ? "bg-yellow-100 dark:bg-yellow-900/30" 
                : isITMCall 
                  ? "bg-red-50/50 dark:bg-red-950/20" 
                  : isITMPut 
                    ? "bg-green-50/50 dark:bg-green-950/20" 
                    : "bg-white dark:bg-slate-900";

              return (
                <Fragment key={strike}>
                  {isAtSpot && (
                    <tr className="bg-blue-500" data-testid="row-spot-price" ref={spotRowRef}>
                      <td colSpan={17} className="py-1.5 text-center">
                        <span className="font-bold text-sm text-white">
                          SPOT: {underlyingPrice.toLocaleString("en-IN", { minimumFractionDigits: 2 })}
                        </span>
                      </td>
                    </tr>
                  )}
                  <tr 
                    className={`${rowBg} border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors`}
                    data-testid={`row-option-strike-${strike}`}
                  >
                    {/* CE OI Bar */}
                    <td className="px-1 py-2.5 border-r border-slate-100 dark:border-slate-800">
                      <div className="w-16 h-3 bg-slate-200 dark:bg-slate-700 rounded-sm overflow-hidden">
                        <div 
                          className="h-full bg-red-500 dark:bg-red-600 transition-all"
                          style={{ width: `${callOIBar}%` }}
                        />
                      </div>
                    </td>
                    {/* CE OI */}
                    <td className={`${cellClass} border-r border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-300 font-semibold`}>
                      {formatOI(call?.openInterest)}
                    </td>
                    {/* CE OI Change % */}
                    <td className={`${cellClass} border-r border-slate-100 dark:border-slate-800 ${getChangeColor(call?.oiChange)}`}>
                      {formatOIChangePercent(call?.openInterest, call?.oiChange)}
                    </td>
                    {/* CE Volume */}
                    <td className={`${cellClass} border-r border-slate-100 dark:border-slate-800 text-slate-500 dark:text-slate-400`}>
                      {formatVolume(call?.volume)}
                    </td>
                    {/* CE IV */}
                    <td className={`${cellClass} border-r border-slate-100 dark:border-slate-800 text-purple-600 dark:text-purple-400`}>
                      {formatIV(call?.impliedVolatility)}
                    </td>
                    {/* CE LTP with arrow */}
                    <td className={`${cellClass} border-r border-slate-100 dark:border-slate-800 ${getChangeBg(call?.change)}`}>
                      <div className="flex items-center justify-end gap-1">
                        {call?.change !== undefined && call.change !== 0 && (
                          call.change > 0 
                            ? <ArrowUp className="h-3 w-3 text-green-500" />
                            : <ArrowDown className="h-3 w-3 text-red-500" />
                        )}
                        <span className={`font-bold ${getChangeColor(call?.change)}`}>
                          {formatPrice(call?.lastPrice)}
                        </span>
                      </div>
                    </td>
                    {/* CE Change */}
                    <td className={`${cellClass} border-r border-slate-100 dark:border-slate-800 ${getChangeColor(call?.change)}`}>
                      {formatChange(call?.change)}
                    </td>
                    {/* CE Bid/Ask */}
                    <td className={`${cellClass} border-r-2 border-slate-300 dark:border-slate-600 text-slate-500 dark:text-slate-400 text-[11px]`}>
                      {formatBidAsk(call?.bid, call?.ask)}
                    </td>
                    {/* Strike */}
                    <td className={`px-3 py-2.5 text-center border-r-2 border-slate-300 dark:border-slate-600 ${isATM ? "bg-yellow-200 dark:bg-yellow-800/50" : "bg-slate-100 dark:bg-slate-700"}`}>
                      <span className={`font-bold text-sm ${isATM ? "text-yellow-800 dark:text-yellow-200" : "text-slate-800 dark:text-slate-200"}`}>
                        {strike.toLocaleString("en-IN")}
                      </span>
                    </td>
                    {/* PE Bid/Ask */}
                    <td className={`${cellClass} border-r border-slate-100 dark:border-slate-800 text-slate-500 dark:text-slate-400 text-[11px]`}>
                      {formatBidAsk(put?.bid, put?.ask)}
                    </td>
                    {/* PE Change */}
                    <td className={`${cellClass} border-r border-slate-100 dark:border-slate-800 ${getChangeColor(put?.change)}`}>
                      {formatChange(put?.change)}
                    </td>
                    {/* PE LTP with arrow */}
                    <td className={`${cellClass} border-r border-slate-100 dark:border-slate-800 ${getChangeBg(put?.change)}`}>
                      <div className="flex items-center justify-end gap-1">
                        <span className={`font-bold ${getChangeColor(put?.change)}`}>
                          {formatPrice(put?.lastPrice)}
                        </span>
                        {put?.change !== undefined && put.change !== 0 && (
                          put.change > 0 
                            ? <ArrowUp className="h-3 w-3 text-green-500" />
                            : <ArrowDown className="h-3 w-3 text-red-500" />
                        )}
                      </div>
                    </td>
                    {/* PE IV */}
                    <td className={`${cellClass} border-r border-slate-100 dark:border-slate-800 text-purple-600 dark:text-purple-400`}>
                      {formatIV(put?.impliedVolatility)}
                    </td>
                    {/* PE Volume */}
                    <td className={`${cellClass} border-r border-slate-100 dark:border-slate-800 text-slate-500 dark:text-slate-400`}>
                      {formatVolume(put?.volume)}
                    </td>
                    {/* PE OI Change % */}
                    <td className={`${cellClass} border-r border-slate-100 dark:border-slate-800 ${getChangeColor(put?.oiChange)}`}>
                      {formatOIChangePercent(put?.openInterest, put?.oiChange)}
                    </td>
                    {/* PE OI */}
                    <td className={`${cellClass} border-r border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-300 font-semibold`}>
                      {formatOI(put?.openInterest)}
                    </td>
                    {/* PE OI Bar */}
                    <td className="px-1 py-2.5">
                      <div className="w-16 h-3 bg-slate-200 dark:bg-slate-700 rounded-sm overflow-hidden">
                        <div 
                          className="h-full bg-green-500 dark:bg-green-600 transition-all"
                          style={{ width: `${putOIBar}%` }}
                        />
                      </div>
                    </td>
                  </tr>
                </Fragment>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Footer Summary */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-2.5 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs">
        <div className="flex flex-wrap items-center gap-4">
          <span className="flex items-center gap-2">
            <div className="w-8 h-2.5 bg-red-500 rounded-sm" />
            <span className="text-slate-600 dark:text-slate-400">CE OI Strength</span>
          </span>
          <span className="flex items-center gap-2">
            <div className="w-8 h-2.5 bg-green-500 rounded-sm" />
            <span className="text-slate-600 dark:text-slate-400">PE OI Strength</span>
          </span>
          <span className="flex items-center gap-1">
            <span className="w-3 h-3 bg-yellow-200 dark:bg-yellow-800 rounded-sm border border-yellow-400" />
            <span className="text-slate-600 dark:text-slate-400">ATM Strike</span>
          </span>
        </div>
        <span className="text-slate-500 dark:text-slate-500">
          Total CE OI: {formatOI(effectiveSummary.totalCallOI)} | Total PE OI: {formatOI(effectiveSummary.totalPutOI)}
        </span>
      </div>
    </div>
  );
}
