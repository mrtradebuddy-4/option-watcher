import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, MessageCircle, Loader2, RefreshCw } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { ChatMessage } from "@shared/schema";

interface ChatData {
  conversation: { id: string } | null;
  messages: ChatMessage[];
}

interface AIChatBoxProps {
  symbol: string;
  expirationDate: string;
  isVisible: boolean;
}

export function AIChatBox({ symbol, expirationDate, isVisible }: AIChatBoxProps) {
  const [message, setMessage] = useState("");
  const [hasAutoGreeted, setHasAutoGreeted] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const { data: chatData, isLoading, isError, refetch } = useQuery<ChatData>({
    queryKey: ['/api/chat', symbol, expirationDate],
    enabled: isVisible && !!symbol && !!expirationDate,
  });

  const messages: ChatMessage[] = chatData?.messages || [];

  const sendMutation = useMutation({
    mutationFn: async (text: string) => {
      const response = await apiRequest('POST', '/api/chat/send', {
        symbol,
        expirationDate,
        message: text,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/chat', symbol, expirationDate] });
      setMessage("");
    },
  });

  // Auto-greet when chat opens and no messages exist
  useEffect(() => {
    if (isVisible && !isLoading && !isError && messages.length === 0 && !hasAutoGreeted && !sendMutation.isPending) {
      setHasAutoGreeted(true);
      // Send automatic greeting request
      sendMutation.mutate("வணக்கம்! இந்த option chain data பற்றி summary சொல்லுங்கள்");
    }
  }, [isVisible, isLoading, isError, messages.length, hasAutoGreeted, sendMutation.isPending]);

  // Reset auto-greet when symbol/expiry changes
  useEffect(() => {
    setHasAutoGreeted(false);
  }, [symbol, expirationDate]);

  useEffect(() => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }
  }, [messages]);

  const handleSend = () => {
    if (!message.trim() || sendMutation.isPending) return;
    sendMutation.mutate(message.trim());
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (!isVisible) return null;

  if (!symbol || !expirationDate) {
    return (
      <Card className="flex flex-col h-40 mt-4">
        <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
          Symbol மற்றும் Expiry date தேர்ந்தெடுக்கவும்
        </div>
      </Card>
    );
  }

  return (
    <Card className="flex flex-col h-80 mt-4">
      <div className="flex items-center gap-2 p-3 border-b">
        <MessageCircle className="w-4 h-4 text-muted-foreground" />
        <span className="text-sm font-medium">AI Chat - {symbol.toUpperCase()}</span>
      </div>
      
      <ScrollArea className="flex-1 p-3" ref={scrollAreaRef}>
        <div className="space-y-3">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
            </div>
          ) : isError ? (
            <div className="flex flex-col items-center justify-center py-8 text-muted-foreground text-sm gap-2">
              <p>Chat load ஆகவில்லை</p>
              <Button variant="outline" size="sm" onClick={() => refetch()} data-testid="button-retry-chat">
                <RefreshCw className="w-3 h-3 mr-1" />
                Retry
              </Button>
            </div>
          ) : messages.length === 0 ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
              <span className="ml-2 text-sm text-muted-foreground">AI loading...</span>
            </div>
          ) : (
            messages.map((msg) => (
              <div
                key={msg.id}
                data-testid={`chat-message-${msg.id}`}
                className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[85%] rounded-lg px-3 py-2 text-sm ${
                    msg.role === "user"
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted"
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.content}</p>
                </div>
              </div>
            ))
          )}
          
          {sendMutation.isPending && (
            <div className="flex justify-start">
              <div className="bg-muted rounded-lg px-3 py-2">
                <Loader2 className="w-4 h-4 animate-spin" />
              </div>
            </div>
          )}
          
          {sendMutation.isError && (
            <div className="flex justify-center">
              <div className="text-xs text-destructive">
                Message send ஆகவில்லை. மீண்டும் முயற்சிக்கவும்.
              </div>
            </div>
          )}
        </div>
      </ScrollArea>

      <div className="p-3 border-t">
        <div className="flex gap-2">
          <Input
            ref={inputRef}
            data-testid="input-chat-message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type your question..."
            disabled={sendMutation.isPending}
            className="flex-1"
          />
          <Button
            data-testid="button-send-chat"
            size="icon"
            onClick={handleSend}
            disabled={!message.trim() || sendMutation.isPending}
          >
            {sendMutation.isPending ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </div>
      </div>
    </Card>
  );
}
