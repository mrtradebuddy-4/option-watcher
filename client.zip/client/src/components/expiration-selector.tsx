import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "lucide-react";

interface ExpirationSelectorProps {
  expirationDates: string[];
  selectedExpiration: string;
  onSelect: (date: string) => void;
}

export function ExpirationSelector({
  expirationDates,
  selectedExpiration,
  onSelect,
}: ExpirationSelectorProps) {
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  const getDaysUntilExpiration = (dateStr: string) => {
    const date = new Date(dateStr);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const diffTime = date.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  return (
    <div className="flex items-center gap-2">
      <Calendar className="h-4 w-4 text-muted-foreground" />
      <Select value={selectedExpiration} onValueChange={onSelect}>
        <SelectTrigger className="w-[280px]" data-testid="select-expiration-date">
          <SelectValue placeholder="Select expiration date" />
        </SelectTrigger>
        <SelectContent>
          {expirationDates.map((date) => {
            const daysUntil = getDaysUntilExpiration(date);
            return (
              <SelectItem key={date} value={date} data-testid={`option-expiration-${date}`}>
                <span className="flex items-center justify-between gap-4 w-full">
                  <span className="font-mono">{formatDate(date)}</span>
                  <span className="text-xs text-muted-foreground">
                    ({daysUntil}d)
                  </span>
                </span>
              </SelectItem>
            );
          })}
        </SelectContent>
      </Select>
    </div>
  );
}
