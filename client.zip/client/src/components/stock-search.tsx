import { useState, useRef, useEffect } from "react";
import { Search, X, TrendingUp } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface StockSearchProps {
  onSearch: (symbol: string) => void;
  isLoading?: boolean;
}

const INDIA_SUGGESTIONS = [
  // Indices
  { symbol: "NIFTY", name: "NIFTY 50" },
  { symbol: "BANKNIFTY", name: "NIFTY Bank" },
  { symbol: "FINNIFTY", name: "NIFTY Financial Services" },
  { symbol: "MIDCPNIFTY", name: "NIFTY Midcap Select" },
  { symbol: "SENSEX", name: "BSE SENSEX" },
  
  // BAJAJ GROUP
  { symbol: "BAJFINANCE", name: "Bajaj Finance" },
  { symbol: "BAJAJFINSV", name: "Bajaj Finserv" },
  { symbol: "BAJAJ-AUTO", name: "Bajaj Auto" },
  { symbol: "BAJAJHLDNG", name: "Bajaj Holdings" },
  { symbol: "BAJAJCON", name: "Bajaj Consumer Care" },
  
  // ADANI GROUP
  { symbol: "ADANIENT", name: "Adani Enterprises" },
  { symbol: "ADANIPORTS", name: "Adani Ports" },
  { symbol: "ADANIGREEN", name: "Adani Green Energy" },
  { symbol: "ADANIPOWER", name: "Adani Power" },
  { symbol: "ATGL", name: "Adani Total Gas" },
  { symbol: "AWL", name: "Adani Wilmar" },
  
  // TATA GROUP
  { symbol: "TCS", name: "Tata Consultancy Services" },
  { symbol: "TATAMOTORS", name: "Tata Motors" },
  { symbol: "TATASTEEL", name: "Tata Steel" },
  { symbol: "TITAN", name: "Titan Company" },
  { symbol: "TATAPOWER", name: "Tata Power" },
  { symbol: "TATACONSUM", name: "Tata Consumer Products" },
  { symbol: "TATATECH", name: "Tata Technologies" },
  { symbol: "TATACOMM", name: "Tata Communications" },
  { symbol: "TATAELXSI", name: "Tata Elxsi" },
  { symbol: "TATACHEM", name: "Tata Chemicals" },
  { symbol: "TRENT", name: "Trent (Westside)" },
  { symbol: "VOLTAS", name: "Voltas" },
  { symbol: "INDHOTEL", name: "Indian Hotels (Taj)" },
  
  // Major Stocks
  { symbol: "RELIANCE", name: "Reliance Industries" },
  { symbol: "HDFCBANK", name: "HDFC Bank" },
  { symbol: "INFY", name: "Infosys" },
  { symbol: "ICICIBANK", name: "ICICI Bank" },
  { symbol: "SBIN", name: "State Bank of India" },
  { symbol: "BHARTIARTL", name: "Bharti Airtel" },
  { symbol: "ITC", name: "ITC Limited" },
  { symbol: "KOTAKBANK", name: "Kotak Mahindra Bank" },
  { symbol: "LT", name: "Larsen & Toubro" },
  { symbol: "AXISBANK", name: "Axis Bank" },
  { symbol: "MARUTI", name: "Maruti Suzuki" },
  { symbol: "SUNPHARMA", name: "Sun Pharma" },
  { symbol: "HCLTECH", name: "HCL Technologies" },
  { symbol: "WIPRO", name: "Wipro" },
  { symbol: "TECHM", name: "Tech Mahindra" },
  
  // Popular F&O Stocks
  { symbol: "IRCTC", name: "IRCTC" },
  { symbol: "PERSISTENT", name: "Persistent Systems" },
  { symbol: "LTIM", name: "LTIMindtree" },
  { symbol: "POLYCAB", name: "Polycab India" },
  { symbol: "HAL", name: "Hindustan Aeronautics" },
  { symbol: "BEL", name: "Bharat Electronics" },
  { symbol: "DMART", name: "Avenue Supermarts" },
  { symbol: "ZOMATO", name: "Zomato" },
  { symbol: "PAYTM", name: "Paytm" },
  { symbol: "COALINDIA", name: "Coal India" },
  { symbol: "ONGC", name: "ONGC" },
  { symbol: "NTPC", name: "NTPC" },
  { symbol: "POWERGRID", name: "Power Grid" },
  { symbol: "HINDALCO", name: "Hindalco" },
  { symbol: "JSWSTEEL", name: "JSW Steel" },
  { symbol: "VEDL", name: "Vedanta" },
  { symbol: "M&M", name: "Mahindra & Mahindra" },
  { symbol: "HEROMOTOCO", name: "Hero MotoCorp" },
  { symbol: "EICHERMOT", name: "Eicher Motors" },
  { symbol: "APOLLOHOSP", name: "Apollo Hospitals" },
  { symbol: "CIPLA", name: "Cipla" },
  { symbol: "DRREDDY", name: "Dr. Reddys" },
  { symbol: "DIVISLAB", name: "Divis Labs" },
  { symbol: "LUPIN", name: "Lupin" },
  { symbol: "BIOCON", name: "Biocon" },
  { symbol: "ASIANPAINT", name: "Asian Paints" },
  { symbol: "PIDILITIND", name: "Pidilite" },
  { symbol: "NESTLEIND", name: "Nestle India" },
  { symbol: "BRITANNIA", name: "Britannia" },
  { symbol: "HINDUNILVR", name: "Hindustan Unilever" },
  { symbol: "DABUR", name: "Dabur" },
  { symbol: "MARICO", name: "Marico" },
  { symbol: "GODREJCP", name: "Godrej Consumer" },
  { symbol: "DLF", name: "DLF" },
  { symbol: "GODREJPROP", name: "Godrej Properties" },
  { symbol: "OBEROIRLTY", name: "Oberoi Realty" },
  { symbol: "PNB", name: "Punjab National Bank" },
  { symbol: "BANKBARODA", name: "Bank of Baroda" },
  { symbol: "CANBK", name: "Canara Bank" },
  { symbol: "INDUSINDBK", name: "IndusInd Bank" },
  { symbol: "FEDERALBNK", name: "Federal Bank" },
  { symbol: "IDFCFIRSTB", name: "IDFC First Bank" },
  { symbol: "SBICARD", name: "SBI Cards" },
  { symbol: "SBILIFE", name: "SBI Life Insurance" },
  { symbol: "HDFCLIFE", name: "HDFC Life Insurance" },
  { symbol: "ICICIPRULI", name: "ICICI Prudential Life" },
  { symbol: "SIEMENS", name: "Siemens" },
  { symbol: "ABB", name: "ABB India" },
  { symbol: "HAVELLS", name: "Havells" },
  { symbol: "MRF", name: "MRF" },
  { symbol: "BOSCHLTD", name: "Bosch" },
  { symbol: "MOTHERSON", name: "Motherson Sumi" },
];

export function StockSearch({ onSearch, isLoading }: StockSearchProps) {
  const [symbol, setSymbol] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const filteredSuggestions = symbol.length >= 1
    ? INDIA_SUGGESTIONS.filter(
        s => s.symbol.toLowerCase().includes(symbol.toLowerCase()) ||
             s.name.toLowerCase().includes(symbol.toLowerCase())
      )
    : INDIA_SUGGESTIONS.slice(0, 6);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanedSymbol = symbol.trim().toUpperCase();
    if (cleanedSymbol) {
      onSearch(cleanedSymbol);
      setShowSuggestions(false);
    }
  };

  const handleSelect = (sym: string) => {
    setSymbol(sym);
    onSearch(sym);
    setShowSuggestions(false);
    setSelectedIndex(-1);
  };

  const handleClear = () => {
    setSymbol("");
    setSelectedIndex(-1);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!showSuggestions || filteredSuggestions.length === 0) return;
    
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIndex(prev => 
        prev < filteredSuggestions.length - 1 ? prev + 1 : 0
      );
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex(prev => 
        prev > 0 ? prev - 1 : filteredSuggestions.length - 1
      );
    } else if (e.key === "Enter" && selectedIndex >= 0) {
      e.preventDefault();
      handleSelect(filteredSuggestions[selectedIndex].symbol);
    } else if (e.key === "Escape") {
      setShowSuggestions(false);
      setSelectedIndex(-1);
    }
  };

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <form onSubmit={handleSubmit} className="flex gap-2 items-center w-full">
      <div ref={containerRef} className="relative flex-1">
        <div className="absolute left-3 top-0 bottom-0 flex items-center pointer-events-none z-10">
          <Search className="h-4 w-4 text-muted-foreground" />
        </div>
        <Input
          ref={inputRef}
          type="text"
          placeholder="Search NSE/BSE (NIFTY, RELIANCE...)"
          value={symbol}
          onChange={(e) => {
            setSymbol(e.target.value.toUpperCase());
            setShowSuggestions(true);
            setSelectedIndex(-1);
          }}
          onFocus={() => setShowSuggestions(true)}
          onKeyDown={handleKeyDown}
          className="pl-10 pr-10 font-mono"
          data-testid="input-stock-symbol"
          autoComplete="off"
        />
        {symbol && (
          <div className="absolute right-1 top-0 bottom-0 flex items-center">
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              onClick={handleClear}
              data-testid="button-clear-search"
            >
              <X className="h-3 w-3" />
            </Button>
          </div>
        )}

        {showSuggestions && filteredSuggestions.length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-1 bg-popover border rounded-md shadow-lg z-[100] max-h-64 overflow-y-auto">
            <div className="p-1">
              {filteredSuggestions.map((suggestion, index) => (
                <button
                  key={suggestion.symbol}
                  type="button"
                  onClick={() => handleSelect(suggestion.symbol)}
                  className={`w-full flex items-center gap-2 px-3 py-2 text-left rounded-sm text-sm hover-elevate ${
                    index === selectedIndex ? "bg-accent" : ""
                  }`}
                  data-testid={`suggestion-${suggestion.symbol}`}
                >
                  <TrendingUp className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                  <span className="font-mono font-medium">{suggestion.symbol}</span>
                  <span className="text-muted-foreground text-xs truncate">{suggestion.name}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
      <Button type="submit" disabled={!symbol.trim() || isLoading} data-testid="button-search-stock">
        {isLoading ? "Loading..." : "Search"}
      </Button>
    </form>
  );
}
