import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, TrendingDown, Activity, ArrowUp, ArrowDown, Minus, Clock, Wifi, BarChart2, Target, Zap } from "lucide-react";
import type { StockQuote, OptionChainData } from "@shared/schema";

interface StockQuoteCardProps {
  quote: StockQuote;
  optionChain?: OptionChainData;
}

export function StockQuoteCard({ quote, optionChain }: StockQuoteCardProps) {
  const isPositive = quote.regularMarketChange >= 0;
  const changePercent = Math.abs(quote.regularMarketChangePercent);
  
  const isIndex = ["NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY", "SENSEX"].includes(quote.symbol);
  
  const getTrend = () => {
    if (changePercent >= 2) return isPositive ? "STRONG BULLISH" : "STRONG BEARISH";
    if (changePercent >= 1) return isPositive ? "BULLISH" : "BEARISH";
    if (changePercent >= 0.3) return isPositive ? "MILDLY BULLISH" : "MILDLY BEARISH";
    return "NEUTRAL";
  };
  
  const getTrendColor = () => {
    const trend = getTrend();
    if (trend.includes("STRONG BULLISH")) return "bg-emerald-600";
    if (trend.includes("BULLISH")) return "bg-emerald-500";
    if (trend.includes("STRONG BEARISH")) return "bg-rose-600";
    if (trend.includes("BEARISH")) return "bg-rose-500";
    return "bg-slate-500";
  };

  const getTrendIcon = () => {
    const trend = getTrend();
    if (trend.includes("BULLISH")) return <ArrowUp className="h-3 w-3" />;
    if (trend.includes("BEARISH")) return <ArrowDown className="h-3 w-3" />;
    return <Minus className="h-3 w-3" />;
  };

  const getSentimentStrength = () => {
    const strength = Math.min(changePercent * 25, 100);
    return strength;
  };
  
  const formatPrice = (price: number) => {
    if (price === 0 || price === undefined || price === null) return "-";
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      minimumFractionDigits: 2,
    }).format(price);
  };

  const formatVolume = (volume: number) => {
    if (!volume || volume === 0) return "-";
    if (volume >= 10000000) {
      return (volume / 10000000).toFixed(2) + " Cr";
    }
    if (volume >= 100000) {
      return (volume / 100000).toFixed(2) + " L";
    }
    if (volume >= 1000) {
      return (volume / 1000).toFixed(1) + "K";
    }
    return volume.toString();
  };

  const formatOICr = (oi: number) => {
    if (!oi || oi === 0) return "-";
    return (oi / 10000000).toFixed(2) + " Cr";
  };

  const getDayRangePosition = () => {
    if (!quote.high || !quote.low || quote.high === quote.low) return 50;
    const range = quote.high - quote.low;
    const position = ((quote.regularMarketPrice - quote.low) / range) * 100;
    return Math.max(0, Math.min(100, position));
  };

  const calculatePCR = () => {
    if (!optionChain || !optionChain.calls || !optionChain.puts) return null;
    const totalCallOI = optionChain.calls.reduce((sum, c) => sum + (c.openInterest || 0), 0);
    const totalPutOI = optionChain.puts.reduce((sum, p) => sum + (p.openInterest || 0), 0);
    if (totalCallOI === 0) return null;
    return (totalPutOI / totalCallOI).toFixed(2);
  };

  const getTotalOI = () => {
    if (!optionChain || !optionChain.calls || !optionChain.puts) return null;
    const totalCallOI = optionChain.calls.reduce((sum, c) => sum + (c.openInterest || 0), 0);
    const totalPutOI = optionChain.puts.reduce((sum, p) => sum + (p.openInterest || 0), 0);
    return { callOI: totalCallOI, putOI: totalPutOI, total: totalCallOI + totalPutOI };
  };

  const getMaxPainStrike = () => {
    if (!optionChain || !optionChain.calls || !optionChain.puts) return null;
    const strikes = new Map<number, number>();
    optionChain.calls.forEach(c => {
      const current = strikes.get(c.strike) || 0;
      strikes.set(c.strike, current + (c.openInterest || 0));
    });
    optionChain.puts.forEach(p => {
      const current = strikes.get(p.strike) || 0;
      strikes.set(p.strike, current + (p.openInterest || 0));
    });
    let maxStrike = 0;
    let maxOI = 0;
    strikes.forEach((oi, strike) => {
      if (oi > maxOI) {
        maxOI = oi;
        maxStrike = strike;
      }
    });
    return maxStrike;
  };

  const pcr = calculatePCR();
  const oiData = getTotalOI();
  const maxPain = getMaxPainStrike();
  const dayRangePos = getDayRangePosition();
  const sentimentStrength = getSentimentStrength();

  const getFormattedTimestamp = () => {
    if (quote.timestamp) {
      try {
        const date = new Date(quote.timestamp);
        return date.toLocaleTimeString('en-IN', { 
          hour: '2-digit', 
          minute: '2-digit',
          second: '2-digit',
          hour12: true
        });
      } catch {
        return new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
      }
    }
    return new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
  };

  const getPCRStatus = () => {
    if (!pcr) return { text: "-", color: "text-muted-foreground", bgColor: "bg-muted/30" };
    const val = parseFloat(pcr);
    if (val > 1.2) return { text: "Bullish", color: "text-emerald-500", bgColor: "bg-emerald-500/10" };
    if (val > 1) return { text: "Mild Bull", color: "text-emerald-400", bgColor: "bg-emerald-500/10" };
    if (val < 0.7) return { text: "Bearish", color: "text-rose-500", bgColor: "bg-rose-500/10" };
    if (val < 1) return { text: "Mild Bear", color: "text-rose-400", bgColor: "bg-rose-500/10" };
    return { text: "Neutral", color: "text-amber-500", bgColor: "bg-amber-500/10" };
  };

  const getMaxPainTrend = () => {
    if (!maxPain || !quote.regularMarketPrice) return { icon: <Minus className="h-2.5 w-2.5" />, color: "text-muted-foreground" };
    const diff = maxPain - quote.regularMarketPrice;
    const pct = (diff / quote.regularMarketPrice) * 100;
    if (pct > 0.5) return { icon: <ArrowUp className="h-2.5 w-2.5" />, color: "text-emerald-500", text: `+${pct.toFixed(1)}%` };
    if (pct < -0.5) return { icon: <ArrowDown className="h-2.5 w-2.5" />, color: "text-rose-500", text: `${pct.toFixed(1)}%` };
    return { icon: <Minus className="h-2.5 w-2.5" />, color: "text-amber-500", text: "~0%" };
  };

  const pcrStatus = getPCRStatus();
  const maxPainTrend = getMaxPainTrend();
  const lastUpdated = getFormattedTimestamp();

  return (
    <Card data-testid={`card-stock-quote-${quote.symbol}`}>
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
        <div className="flex flex-col gap-0.5">
          <div className="flex items-center gap-2">
            <CardTitle className="text-xl sm:text-2xl font-bold font-mono">{quote.symbol}</CardTitle>
            {isIndex && (
              <Badge variant="outline" className="text-[10px] border-blue-500 text-blue-500">INDEX</Badge>
            )}
          </div>
          <p className="text-xs sm:text-sm text-muted-foreground">
            {quote.shortName || quote.symbol}
          </p>
        </div>
        <div className="flex flex-col items-end gap-1">
          <Badge 
            variant={isPositive ? "default" : "destructive"} 
            className={`flex items-center gap-1 ${isPositive ? "bg-emerald-600" : "bg-rose-600"}`}
          >
            {isPositive ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
            {isPositive ? "+" : ""}{quote.regularMarketChangePercent.toFixed(2)}%
          </Badge>
          <Badge className={`flex items-center gap-1 text-white text-[9px] ${getTrendColor()}`}>
            {getTrendIcon()}
            <span>{getTrend()}</span>
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Price and Change */}
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-0.5">
            <p className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">LTP</p>
            <p className="text-lg sm:text-xl font-bold font-mono" data-testid="text-stock-price">
              {formatPrice(quote.regularMarketPrice)}
            </p>
          </div>
          <div className="space-y-0.5">
            <p className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">Change</p>
            <p className={`text-base font-mono font-semibold flex items-center gap-1 ${isPositive ? "text-emerald-500" : "text-rose-500"}`}>
              {isPositive ? <ArrowUp className="h-3.5 w-3.5" /> : <ArrowDown className="h-3.5 w-3.5" />}
              {isPositive ? "+" : ""}{formatPrice(quote.regularMarketChange)}
              <span className="text-xs">({isPositive ? "+" : ""}{quote.regularMarketChangePercent.toFixed(2)}%)</span>
            </p>
          </div>
        </div>

        {/* Day Range with Labels */}
        <div className="space-y-1.5 pt-2 border-t border-border">
          <div className="flex justify-between text-[10px]">
            <span className="text-muted-foreground">Day Low</span>
            <span className="font-medium text-muted-foreground">Day Range</span>
            <span className="text-muted-foreground">Day High</span>
          </div>
          <div className="flex justify-between text-xs font-mono">
            <span className="text-rose-500 font-semibold">{formatPrice(quote.low)}</span>
            <span className="text-emerald-500 font-semibold">{formatPrice(quote.high)}</span>
          </div>
          <div className="relative h-2.5 bg-gradient-to-r from-rose-500/40 via-amber-500/40 to-emerald-500/40 rounded-full overflow-visible">
            <div 
              className="absolute top-1/2 -translate-y-1/2 w-3.5 h-3.5 bg-primary rounded-full border-2 border-background shadow-lg z-10 transition-all duration-300"
              style={{ left: `calc(${dayRangePos}% - 7px)` }}
              data-testid="indicator-day-range"
            />
          </div>
        </div>

        {/* Sentiment Strength */}
        <div className="space-y-1.5">
          <div className="flex justify-between items-center">
            <span className="text-[10px] text-muted-foreground flex items-center gap-1">
              <Zap className="h-3 w-3" />
              Sentiment Strength
            </span>
            <span className={`text-[10px] font-semibold flex items-center gap-0.5 ${isPositive ? "text-emerald-500" : "text-rose-500"}`}>
              {isPositive ? <ArrowUp className="h-2.5 w-2.5" /> : <ArrowDown className="h-2.5 w-2.5" />}
              {sentimentStrength.toFixed(0)}% {isPositive ? "Bullish" : "Bearish"}
            </span>
          </div>
          <Progress 
            value={sentimentStrength} 
            className={`h-2 ${isPositive ? "[&>div]:bg-gradient-to-r [&>div]:from-emerald-400 [&>div]:to-emerald-600" : "[&>div]:bg-gradient-to-r [&>div]:from-rose-400 [&>div]:to-rose-600"}`}
          />
        </div>
        
        {/* OHLC Grid */}
        <div className="grid grid-cols-4 gap-2 pt-2 border-t border-border">
          <div className="space-y-0.5 text-center p-1.5 rounded bg-muted/30">
            <p className="text-[9px] font-medium uppercase text-muted-foreground">Open</p>
            <p className="text-xs font-mono font-medium">{formatPrice(quote.open)}</p>
          </div>
          <div className="space-y-0.5 text-center p-1.5 rounded bg-emerald-500/10">
            <p className="text-[9px] font-medium uppercase text-muted-foreground">High</p>
            <p className="text-xs font-mono font-medium text-emerald-500">{formatPrice(quote.high)}</p>
          </div>
          <div className="space-y-0.5 text-center p-1.5 rounded bg-rose-500/10">
            <p className="text-[9px] font-medium uppercase text-muted-foreground">Low</p>
            <p className="text-xs font-mono font-medium text-rose-500">{formatPrice(quote.low)}</p>
          </div>
          <div className="space-y-0.5 text-center p-1.5 rounded bg-muted/30">
            <p className="text-[9px] font-medium uppercase text-muted-foreground">Prev Close</p>
            <p className="text-xs font-mono font-medium">{formatPrice(quote.previousClose)}</p>
          </div>
        </div>

        {/* Circuit Limits and Volume */}
        <div className="grid grid-cols-3 gap-2 pt-2 border-t border-border">
          <div className="space-y-0.5 text-center p-1.5 rounded bg-emerald-500/10">
            <p className="text-[9px] font-medium uppercase text-muted-foreground">Upper Circuit</p>
            <p className="text-xs font-mono font-medium text-emerald-500">
              {quote.yearHigh > 0 ? formatPrice(quote.yearHigh) : "No Limit"}
            </p>
          </div>
          <div className="space-y-0.5 text-center p-1.5 rounded bg-rose-500/10">
            <p className="text-[9px] font-medium uppercase text-muted-foreground">Lower Circuit</p>
            <p className="text-xs font-mono font-medium text-rose-500">
              {quote.yearLow > 0 ? formatPrice(quote.yearLow) : "No Limit"}
            </p>
          </div>
          <div className="space-y-0.5 text-center p-1.5 rounded bg-blue-500/10">
            <p className="text-[9px] font-medium uppercase text-muted-foreground">Volume</p>
            <div className="flex items-center justify-center gap-1">
              <Activity className="h-2.5 w-2.5 text-blue-500" />
              <p className="text-xs font-mono font-medium text-blue-500">{formatVolume(quote.regularMarketVolume)}</p>
            </div>
          </div>
        </div>

        {/* F&O Data */}
        {optionChain && optionChain.calls && optionChain.calls.length > 0 && (
          <div className="pt-2 border-t border-border space-y-2">
            <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
              <BarChart2 className="h-3 w-3" />
              <span>F&O Market Data</span>
            </div>
            <div className="grid grid-cols-4 gap-2">
              <div className={`space-y-0.5 text-center p-1.5 rounded border ${pcrStatus.bgColor} border-current/20`}>
                <p className="text-[9px] font-medium uppercase text-muted-foreground">PCR</p>
                <p className={`text-sm font-mono font-bold ${pcrStatus.color}`}>
                  {pcr || "-"}
                </p>
                <p className={`text-[8px] font-semibold ${pcrStatus.color}`}>{pcrStatus.text}</p>
              </div>
              <div className="space-y-0.5 text-center p-1.5 rounded bg-purple-500/10 border border-purple-500/20">
                <p className="text-[9px] font-medium uppercase text-muted-foreground flex items-center justify-center gap-0.5">
                  <Target className="h-2.5 w-2.5" />
                  Max Pain
                </p>
                <p className="text-sm font-mono font-bold text-purple-500">
                  {maxPain ? maxPain.toLocaleString("en-IN") : "-"}
                </p>
                {maxPain && (
                  <p className={`text-[8px] font-semibold flex items-center justify-center gap-0.5 ${maxPainTrend.color}`}>
                    {maxPainTrend.icon}
                    {maxPainTrend.text}
                  </p>
                )}
              </div>
              <div className="space-y-0.5 text-center p-1.5 rounded bg-amber-500/10 border border-amber-500/20">
                <p className="text-[9px] font-medium uppercase text-muted-foreground">Call OI</p>
                <p className="text-xs font-mono font-bold text-amber-500">
                  {oiData ? formatOICr(oiData.callOI) : "-"}
                </p>
              </div>
              <div className="space-y-0.5 text-center p-1.5 rounded bg-emerald-500/10 border border-emerald-500/20">
                <p className="text-[9px] font-medium uppercase text-muted-foreground">Put OI</p>
                <p className="text-xs font-mono font-bold text-emerald-500">
                  {oiData ? formatOICr(oiData.putOI) : "-"}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between pt-2 border-t border-border text-[9px] text-muted-foreground">
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            <span data-testid="text-update-time">Updated: {lastUpdated}</span>
          </div>
          <div className="flex items-center gap-1">
            <Wifi className="h-3 w-3 text-emerald-500" />
            <Badge variant="outline" className="text-[8px] h-4 px-1 border-emerald-500/50 text-emerald-500">
              Upstox API
            </Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
