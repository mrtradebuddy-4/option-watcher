import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Sparkles, RefreshCw, Brain, TrendingUp, AlertTriangle, Target } from "lucide-react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { AiAnalysis } from "@shared/schema";

interface AiAnalysisPanelProps {
  symbol: string;
  expirationDate: string;
  market?: "US" | "INDIA";
}

export function AiAnalysisPanel({ symbol, expirationDate, market = "US" }: AiAnalysisPanelProps) {
  const [isStreaming, setIsStreaming] = useState(false);

  // Fetch existing analysis
  const { data: existingAnalysis, isLoading: isLoadingExisting } = useQuery<AiAnalysis>({
    queryKey: ["/api/analysis", symbol, expirationDate],
    enabled: !!symbol && !!expirationDate,
  });

  // Request new analysis
  const analysisMutation = useMutation({
    mutationFn: async () => {
      setIsStreaming(true);
      const response = await apiRequest("POST", "/api/analyze", {
        symbol,
        expirationDate,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/analysis", symbol, expirationDate] });
      setIsStreaming(false);
    },
    onError: () => {
      setIsStreaming(false);
    },
  });

  const isLoading = isLoadingExisting || analysisMutation.isPending || isStreaming;
  const analysis = analysisMutation.data?.analysis || existingAnalysis?.analysis;

  const renderAnalysis = () => {
    if (!analysis) return null;

    // Parse and style the analysis text
    const lines = analysis.split("\n").filter((line: string) => line.trim());
    
    return (
      <div className="prose prose-sm dark:prose-invert max-w-none space-y-3">
        {lines.map((line: string, index: number) => {
          // Check for headers
          if (line.startsWith("##")) {
            return (
              <h3 key={index} className="text-base font-semibold flex items-center gap-2 mt-4 first:mt-0">
                {line.includes("Bullish") && <TrendingUp className="h-4 w-4 text-green-500" />}
                {line.includes("Risk") && <AlertTriangle className="h-4 w-4 text-amber-500" />}
                {line.includes("Recommendation") && <Target className="h-4 w-4 text-blue-500" />}
                {line.replace(/^##\s*/, "")}
              </h3>
            );
          }
          // Check for bullet points
          if (line.startsWith("-") || line.startsWith("*")) {
            return (
              <p key={index} className="text-sm text-muted-foreground pl-4 border-l-2 border-muted">
                {line.replace(/^[-*]\s*/, "")}
              </p>
            );
          }
          // Regular paragraph
          return (
            <p key={index} className="text-sm leading-relaxed">
              {line}
            </p>
          );
        })}
      </div>
    );
  };

  return (
    <Card className="h-full flex flex-col" data-testid="card-ai-analysis">
      <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0 pb-4">
        <div className="flex items-center gap-2">
          <Brain className="h-5 w-5 text-purple-500" />
          <CardTitle className="text-lg">AI Analysis</CardTitle>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => analysisMutation.mutate()}
          disabled={isLoading || !symbol || market === "INDIA"}
          data-testid="button-analyze"
        >
          {isLoading ? (
            <>
              <RefreshCw className="h-3 w-3 mr-1 animate-spin" />
              Analyzing...
            </>
          ) : (
            <>
              <Sparkles className="h-3 w-3 mr-1" />
              Analyze
            </>
          )}
        </Button>
      </CardHeader>
      <CardContent className="flex-1 overflow-hidden">
        <ScrollArea className="h-full pr-4">
          {market === "INDIA" ? (
            <div className="flex flex-col items-center justify-center h-48 text-center">
              <Brain className="h-12 w-12 text-muted-foreground/30 mb-4" />
              <p className="text-muted-foreground">
                AI analysis is currently available for US market only. Switch to US market to use this feature.
              </p>
            </div>
          ) : !symbol ? (
            <div className="flex flex-col items-center justify-center h-48 text-center">
              <Brain className="h-12 w-12 text-muted-foreground/30 mb-4" />
              <p className="text-muted-foreground">
                Search for a stock to get AI-powered analysis of its option chain
              </p>
            </div>
          ) : isLoading && !analysis ? (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Skeleton className="h-4 w-4 rounded-full" />
                <Skeleton className="h-4 w-32" />
              </div>
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
              <div className="flex items-center gap-2 mt-6">
                <Skeleton className="h-4 w-4 rounded-full" />
                <Skeleton className="h-4 w-24" />
              </div>
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-5/6" />
            </div>
          ) : analysis ? (
            <div className="space-y-4">
              <div className="flex items-center gap-2 flex-wrap">
                <Badge variant="outline" className="font-mono">{symbol}</Badge>
                <Badge variant="secondary">{expirationDate}</Badge>
              </div>
              {renderAnalysis()}
              {existingAnalysis?.createdAt && (
                <p className="text-xs text-muted-foreground mt-4 pt-4 border-t">
                  Last analyzed: {new Date(existingAnalysis.createdAt).toLocaleString()}
                </p>
              )}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-48 text-center">
              <Sparkles className="h-12 w-12 text-muted-foreground/30 mb-4" />
              <p className="text-muted-foreground">
                Click "Analyze" to get AI insights on {symbol}'s option chain
              </p>
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
