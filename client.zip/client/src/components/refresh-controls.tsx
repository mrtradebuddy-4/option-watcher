import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, Clock, Pause, Play } from "lucide-react";

interface RefreshControlsProps {
  onRefresh: () => void;
  lastUpdated?: string;
  isLoading?: boolean;
}

const REFRESH_INTERVALS = [
  { value: "0", label: "Manual" },
  { value: "30", label: "30 seconds" },
  { value: "60", label: "1 minute" },
  { value: "300", label: "5 minutes" },
];

export function RefreshControls({ onRefresh, lastUpdated, isLoading }: RefreshControlsProps) {
  const [interval, setInterval] = useState("0");
  const [isPaused, setIsPaused] = useState(false);
  const [countdown, setCountdown] = useState(0);

  const handleRefresh = useCallback(() => {
    if (!isLoading) {
      onRefresh();
      setCountdown(parseInt(interval));
    }
  }, [onRefresh, isLoading, interval]);

  useEffect(() => {
    if (interval === "0" || isPaused) {
      setCountdown(0);
      return;
    }

    const intervalSeconds = parseInt(interval);
    setCountdown(intervalSeconds);

    const timer = globalThis.setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          handleRefresh();
          return intervalSeconds;
        }
        return prev - 1;
      });
    }, 1000);

    return () => globalThis.clearInterval(timer);
  }, [interval, isPaused, handleRefresh]);

  const formatCountdown = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return mins > 0 ? `${mins}:${secs.toString().padStart(2, "0")}` : `${secs}s`;
  };

  const formatLastUpdated = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  };

  return (
    <div className="flex items-center gap-3 flex-wrap">
      {lastUpdated && (
        <div className="flex items-center gap-1 text-sm text-muted-foreground">
          <Clock className="h-3 w-3" />
          <span className="font-mono">{formatLastUpdated(lastUpdated)}</span>
        </div>
      )}
      
      <div className="flex items-center gap-2">
        <Select value={interval} onValueChange={setInterval}>
          <SelectTrigger className="w-[130px]" data-testid="select-refresh-interval">
            <SelectValue placeholder="Refresh interval" />
          </SelectTrigger>
          <SelectContent>
            {REFRESH_INTERVALS.map((item) => (
              <SelectItem key={item.value} value={item.value}>
                {item.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {interval !== "0" && (
          <>
            <Button
              size="icon"
              variant="ghost"
              onClick={() => setIsPaused(!isPaused)}
              data-testid="button-toggle-pause"
            >
              {isPaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
            </Button>
            {!isPaused && countdown > 0 && (
              <Badge variant="secondary" className="font-mono">
                {formatCountdown(countdown)}
              </Badge>
            )}
          </>
        )}
      </div>

      <Button
        variant="outline"
        size="icon"
        onClick={handleRefresh}
        disabled={isLoading}
        data-testid="button-refresh"
      >
        <RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
      </Button>
    </div>
  );
}
