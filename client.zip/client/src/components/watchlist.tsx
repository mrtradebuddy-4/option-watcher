import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Star, Plus, X, ArrowUp, ArrowDown, Minus, RefreshCw, Clock } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { WatchlistItem, StockQuote } from "@shared/schema";

interface WatchlistProps {
  currentSymbol: string;
  onSelectSymbol: (symbol: string) => void;
}

const REFRESH_INTERVALS = [
  { value: "5000", label: "5s" },
  { value: "30000", label: "30s" },
  { value: "60000", label: "1m" },
];

export function Watchlist({ currentSymbol, onSelectSymbol }: WatchlistProps) {
  const [refreshInterval, setRefreshInterval] = useState("30000");
  const [lastRefreshTime, setLastRefreshTime] = useState<Date>(new Date());

  const { data: watchlist, isLoading: isLoadingWatchlist } = useQuery<WatchlistItem[]>({
    queryKey: ["/api/watchlist"],
  });

  const { data: quotes, isLoading: isLoadingQuotes, dataUpdatedAt } = useQuery<Record<string, StockQuote>>({
    queryKey: ["/api/watchlist/quotes"],
    enabled: !!watchlist && watchlist.length > 0,
    refetchInterval: parseInt(refreshInterval),
  });

  const addMutation = useMutation({
    mutationFn: async (symbol: string) => {
      const res = await apiRequest("POST", "/api/watchlist", { symbol });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/watchlist"] });
    },
  });

  const removeMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("DELETE", `/api/watchlist/${id}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/watchlist"] });
    },
  });

  const isInWatchlist = watchlist?.some(item => item.symbol === currentSymbol);
  const isLoading = isLoadingWatchlist || isLoadingQuotes;

  const getLastUpdatedTime = () => {
    if (dataUpdatedAt) {
      const date = new Date(dataUpdatedAt);
      return date.toLocaleTimeString('en-IN', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true
      });
    }
    return new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
  };

  const getTrendInfo = (change: number, pctChange: number) => {
    const isPositive = change >= 0;
    const absChange = Math.abs(pctChange);
    
    if (absChange >= 2) {
      return {
        icon: isPositive ? <ArrowUp className="h-2.5 w-2.5" /> : <ArrowDown className="h-2.5 w-2.5" />,
        label: isPositive ? "Strong Bull" : "Strong Bear",
        bgColor: isPositive ? "bg-emerald-600" : "bg-rose-600",
        textColor: isPositive ? "text-emerald-500" : "text-rose-500",
      };
    }
    if (absChange >= 1) {
      return {
        icon: isPositive ? <ArrowUp className="h-2.5 w-2.5" /> : <ArrowDown className="h-2.5 w-2.5" />,
        label: isPositive ? "Bullish" : "Bearish",
        bgColor: isPositive ? "bg-emerald-500" : "bg-rose-500",
        textColor: isPositive ? "text-emerald-500" : "text-rose-500",
      };
    }
    if (absChange >= 0.3) {
      return {
        icon: isPositive ? <ArrowUp className="h-2.5 w-2.5" /> : <ArrowDown className="h-2.5 w-2.5" />,
        label: isPositive ? "Mild Bull" : "Mild Bear",
        bgColor: isPositive ? "bg-emerald-400" : "bg-rose-400",
        textColor: isPositive ? "text-emerald-400" : "text-rose-400",
      };
    }
    return {
      icon: <Minus className="h-2.5 w-2.5" />,
      label: "Neutral",
      bgColor: "bg-slate-500",
      textColor: "text-muted-foreground",
    };
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      minimumFractionDigits: 2,
    }).format(price);
  };

  return (
    <Card className="h-full flex flex-col" data-testid="card-watchlist">
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-3">
        <div className="flex items-center gap-2">
          <Star className="h-5 w-5 text-amber-500" />
          <CardTitle className="text-lg">Watchlist</CardTitle>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            <RefreshCw className="h-3 w-3 text-muted-foreground" />
            <Select value={refreshInterval} onValueChange={setRefreshInterval}>
              <SelectTrigger className="h-7 w-16 text-xs" data-testid="select-refresh-interval">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {REFRESH_INTERVALS.map((interval) => (
                  <SelectItem key={interval.value} value={interval.value}>
                    {interval.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {currentSymbol && !isInWatchlist && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => addMutation.mutate(currentSymbol)}
              disabled={addMutation.isPending}
              data-testid="button-add-to-watchlist"
            >
              <Plus className="h-3 w-3 mr-1" />
              Add
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="flex-1 overflow-hidden">
        <ScrollArea className="h-full">
          {isLoading ? (
            <div className="space-y-2">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center justify-between p-2">
                  <Skeleton className="h-6 w-16" />
                  <Skeleton className="h-6 w-20" />
                </div>
              ))}
            </div>
          ) : !watchlist || watchlist.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 text-center">
              <Star className="h-8 w-8 text-muted-foreground/30 mb-2" />
              <p className="text-sm text-muted-foreground">
                No stocks in watchlist
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Search for a stock and add it to your watchlist
              </p>
            </div>
          ) : (
            <div className="space-y-1">
              {watchlist.map((item) => {
                const quote = quotes?.[item.symbol] as any;
                const change = quote?.regularMarketChange || 0;
                const pctChange = quote?.regularMarketChangePercent || 0;
                const isPositive = change >= 0;
                const isSelected = item.symbol === currentSymbol;
                const trendInfo = getTrendInfo(change, pctChange);
                const lastUpdated = getLastUpdatedTime();

                return (
                  <div
                    key={item.id}
                    className={`flex items-center justify-between p-2 rounded-md hover-elevate cursor-pointer group ${
                      isSelected ? "bg-accent" : ""
                    }`}
                    onClick={() => onSelectSymbol(item.symbol)}
                    data-testid={`watchlist-item-${item.symbol}`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="font-mono font-medium text-sm">{item.symbol}</span>
                      {isSelected && (
                        <Badge variant="secondary" className="text-[10px]">Active</Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      {quote ? (
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div 
                              className="flex items-center gap-1.5 cursor-help"
                              data-testid={`quote-${item.symbol}`}
                            >
                              <span className={`font-mono text-sm font-semibold ${isPositive ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}`}>
                                {formatPrice(quote.regularMarketPrice)}
                              </span>
                              <span className={`font-mono text-xs font-bold flex items-center gap-0.5 ${isPositive ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}`}>
                                {isPositive ? (
                                  <ArrowUp className="h-3 w-3" />
                                ) : (
                                  <ArrowDown className="h-3 w-3" />
                                )}
                                {Math.abs(pctChange).toFixed(2)}%
                              </span>
                            </div>
                          </TooltipTrigger>
                          <TooltipContent side="top" className="text-xs bg-slate-800 text-white">
                            <div className="space-y-1">
                              <div className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                <span>Last updated: {lastUpdated}</span>
                              </div>
                              <div className={`font-medium ${isPositive ? "text-green-400" : "text-red-400"}`}>
                                Change: {isPositive ? "+" : ""}{change.toFixed(2)} ({isPositive ? "+" : ""}{pctChange.toFixed(2)}%)
                              </div>
                              <div className="text-slate-400">{trendInfo.label}</div>
                            </div>
                          </TooltipContent>
                        </Tooltip>
                      ) : (
                        <span className="text-xs text-muted-foreground">Loading...</span>
                      )}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 invisible group-hover:visible"
                        onClick={(e) => {
                          e.stopPropagation();
                          removeMutation.mutate(item.id);
                        }}
                        data-testid={`button-remove-${item.symbol}`}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </ScrollArea>

        {/* Footer with last update time */}
        {watchlist && watchlist.length > 0 && (
          <div className="flex items-center justify-center gap-1 pt-2 mt-2 border-t border-border text-[10px] text-muted-foreground">
            <Clock className="h-3 w-3" />
            <span>Auto-refresh: {REFRESH_INTERVALS.find(i => i.value === refreshInterval)?.label}</span>
            <span className="mx-1">|</span>
            <span>Updated: {getLastUpdatedTime()}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
