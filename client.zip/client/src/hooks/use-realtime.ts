import { useEffect, useRef, useCallback, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";

interface PriceUpdate {
  type: "price_update";
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  previousPrice: number;
  timestamp: string;
}

interface ConnectionMessage {
  type: "connected";
  message: string;
}

type WebSocketMessage = PriceUpdate | ConnectionMessage;

interface UseRealtimeOptions {
  onPriceChange?: (update: PriceUpdate) => void;
  autoAnalyze?: boolean;
  currentSymbol?: string;
  currentExpiration?: string;
}

export function useRealtime(options: UseRealtimeOptions = {}) {
  const { onPriceChange, autoAnalyze = false, currentSymbol, currentExpiration } = options;
  const { toast } = useToast();
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const autoAnalyzeTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const lastAnalysisTimeRef = useRef<number>(0);
  const isAnalyzingRef = useRef<boolean>(false);
  const [isConnected, setIsConnected] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<PriceUpdate | null>(null);

  // Clear auto-analyze timeout when symbol, expiration, or autoAnalyze changes
  useEffect(() => {
    if (autoAnalyzeTimeoutRef.current) {
      clearTimeout(autoAnalyzeTimeoutRef.current);
      autoAnalyzeTimeoutRef.current = null;
    }
    // Reset analyzing state when context changes
    if (!autoAnalyze) {
      isAnalyzingRef.current = false;
    }
  }, [currentSymbol, currentExpiration, autoAnalyze]);

  const triggerAutoAnalysis = useCallback(async (symbol: string, expiration: string) => {
    // Prevent concurrent analysis
    if (isAnalyzingRef.current) return;
    
    const now = Date.now();
    const MIN_ANALYSIS_INTERVAL = 60000; // 1 minute minimum between auto-analyses
    
    if (now - lastAnalysisTimeRef.current < MIN_ANALYSIS_INTERVAL) {
      return; // Skip if analyzed too recently
    }

    // Guard against missing data
    if (!symbol || !expiration) return;
    
    isAnalyzingRef.current = true;
    
    try {
      lastAnalysisTimeRef.current = now;
      await apiRequest("POST", "/api/analyze", { symbol, expirationDate: expiration });
      queryClient.invalidateQueries({ queryKey: ["/api/analysis", symbol, expiration] });
      toast({
        title: "Auto AI Analysis",
        description: `${symbol} analysis updated`,
        duration: 3000,
      });
    } catch (error) {
      // Clear the last analysis time so it can retry later
      lastAnalysisTimeRef.current = 0;
      console.error("Auto-analysis failed:", error);
    } finally {
      isAnalyzingRef.current = false;
    }
  }, [toast]);

  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    try {
      const ws = new WebSocket(wsUrl);

      ws.onopen = () => {
        console.log("WebSocket connected");
        setIsConnected(true);
      };

      ws.onmessage = (event) => {
        try {
          const message: WebSocketMessage = JSON.parse(event.data);

          if (message.type === "connected") {
            toast({
              title: "Real-time Updates",
              description: "Live price updates enabled",
              duration: 2000,
            });
          } else if (message.type === "price_update") {
            setLastUpdate(message);
            
            // Show toast for significant price changes
            const priceDiff = Math.abs(message.changePercent);
            if (priceDiff >= 0.5) {
              const isUp = message.change > 0;
              toast({
                title: `${message.symbol} ${isUp ? "Up" : "Down"}`,
                description: `₹${message.price.toLocaleString("en-IN", { minimumFractionDigits: 2 })} (${isUp ? "+" : ""}${message.changePercent.toFixed(2)}%)`,
                variant: isUp ? "default" : "destructive",
                duration: 4000,
              });
            }

            // Invalidate watchlist quotes to refresh UI
            queryClient.invalidateQueries({ queryKey: ["/api/watchlist/quotes"] });

            // Trigger callback if provided
            if (onPriceChange) {
              onPriceChange(message);
            }

            // Auto-analyze if enabled and symbol matches (with debouncing)
            if (autoAnalyze && currentSymbol && currentExpiration && message.symbol === currentSymbol) {
              // Only schedule if no pending analysis and not currently analyzing
              if (!autoAnalyzeTimeoutRef.current && !isAnalyzingRef.current) {
                // Debounce: wait 5 seconds before triggering analysis
                autoAnalyzeTimeoutRef.current = setTimeout(async () => {
                  try {
                    await triggerAutoAnalysis(currentSymbol, currentExpiration);
                  } finally {
                    // Always clear the ref after completion, even if guards short-circuit
                    autoAnalyzeTimeoutRef.current = null;
                  }
                }, 5000);
              }
            }
          }
        } catch (error) {
          console.error("WebSocket message parse error:", error);
        }
      };

      ws.onclose = () => {
        console.log("WebSocket disconnected");
        setIsConnected(false);
        wsRef.current = null;

        // Attempt reconnect after 5 seconds
        if (reconnectTimeoutRef.current) {
          clearTimeout(reconnectTimeoutRef.current);
        }
        reconnectTimeoutRef.current = setTimeout(connect, 5000);
      };

      ws.onerror = (error) => {
        console.error("WebSocket error:", error);
        ws.close();
      };

      wsRef.current = ws;
    } catch (error) {
      console.error("WebSocket connection failed:", error);
    }
  }, [toast, onPriceChange, autoAnalyze, currentSymbol, currentExpiration]);

  useEffect(() => {
    connect();

    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (autoAnalyzeTimeoutRef.current) {
        clearTimeout(autoAnalyzeTimeoutRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [connect]);

  return {
    isConnected,
    lastUpdate,
  };
}
