import { useState, useCallback, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ThemeToggle } from "@/components/theme-toggle";
import { StockSearch } from "@/components/stock-search";
import { StockQuoteCard } from "@/components/stock-quote-card";
import { OptionChainTable } from "@/components/option-chain-table";
import { ExpirationSelector } from "@/components/expiration-selector";
import { Watchlist } from "@/components/watchlist";
import { AIChatBox } from "@/components/ai-chat-box";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { TrendingUp, BarChart3, AlertCircle, Link2, Link2Off, Brain, Loader2, TableProperties, Wifi, WifiOff, MessageCircle, RefreshCw, Clock, Pause, Play, CandlestickChart as CandlestickIcon } from "lucide-react";
import { CandlestickChart } from "@/components/candlestick-chart";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { StockQuote, OptionChainData, AiAnalysis } from "@shared/schema";

interface UpstoxStatus {
  connected: boolean;
  hasToken: boolean;
  expiry: string | null;
}

export default function Dashboard() {
  const [symbol, setSymbol] = useState("");
  const [selectedExpiration, setSelectedExpiration] = useState("");
  const [activeTab, setActiveTab] = useState<"chain" | "ai">("chain");
  const [autoAnalyzeEnabled, setAutoAnalyzeEnabled] = useState(true);
  const [showChat, setShowChat] = useState(false);
  const [showChart, setShowChart] = useState(false);
  const [refreshInterval, setRefreshInterval] = useState("30"); // Auto-refresh every 30 seconds
  const [isPaused, setIsPaused] = useState(false);
  const [countdown, setCountdown] = useState(30);
  const lastDataHashRef = useRef<string>("");
  const { toast } = useToast();

  const INDIA_INDICES = ["NIFTY", "BANKNIFTY", "FINNIFTY", "SENSEX"];

  const { data: upstoxStatus, refetch: refetchUpstoxStatus } = useQuery<UpstoxStatus>({
    queryKey: ["/api/upstox/status"],
  });

  const { data: upstoxLoginData } = useQuery<{ authUrl: string; redirectUri: string }>({
    queryKey: ["/api/upstox/login"],
    enabled: !upstoxStatus?.connected,
  });

  const disconnectUpstox = useMutation({
    mutationFn: () => apiRequest("POST", "/api/upstox/disconnect"),
    onSuccess: () => {
      refetchUpstoxStatus();
      queryClient.invalidateQueries({ queryKey: ["/api/upstox"] });
    },
  });

  const { 
    data: quote, 
    isLoading: isLoadingQuote,
    error: quoteError,
    refetch: refetchQuote 
  } = useQuery<StockQuote>({
    queryKey: ["/api/upstox/quote", symbol],
    enabled: !!symbol && upstoxStatus?.connected,
  });

  const { 
    data: optionChain, 
    isLoading: isLoadingOptions,
    error: optionsError,
    refetch: refetchOptions 
  } = useQuery<OptionChainData>({
    queryKey: ["/api/upstox/options", symbol, selectedExpiration],
    enabled: !!symbol && !!selectedExpiration && upstoxStatus?.connected,
  });

  const { 
    data: expirationData, 
    isLoading: isLoadingExpirations 
  } = useQuery<{ expirationDates: string[] }>({
    queryKey: ["/api/upstox/expirations", symbol],
    enabled: !!symbol && upstoxStatus?.connected,
  });

  const { 
    data: analysisData,
    isLoading: isLoadingAnalysis,
    refetch: refetchAnalysis
  } = useQuery<AiAnalysis>({
    queryKey: ["/api/analysis", symbol, selectedExpiration],
    enabled: !!symbol && !!selectedExpiration && activeTab === "ai",
  });

  const analyzeMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/analyze", { 
      symbol, 
      expirationDate: selectedExpiration 
    }),
    onSuccess: () => {
      refetchAnalysis();
    },
  });

  const handleAnalyze = () => {
    setActiveTab("ai");
    analyzeMutation.mutate();
  };

  const handleSearch = useCallback((newSymbol: string) => {
    setSymbol(newSymbol);
    setSelectedExpiration("");
    setActiveTab("chain");
  }, []);

  if (expirationData?.expirationDates?.length && !selectedExpiration) {
    setSelectedExpiration(expirationData.expirationDates[0]);
  }

  const handleRefresh = useCallback(() => {
    if (symbol) {
      refetchQuote();
      if (selectedExpiration) {
        refetchOptions();
      }
      queryClient.invalidateQueries({ queryKey: ["/api/upstox/expirations", symbol] });
    }
  }, [symbol, selectedExpiration, refetchQuote, refetchOptions]);

  const isLoading = isLoadingQuote || isLoadingOptions || isLoadingExpirations;

  // Auto-refresh timer effect
  useEffect(() => {
    if (refreshInterval === "0" || isPaused || !symbol || !selectedExpiration || !upstoxStatus?.connected) {
      return;
    }

    const intervalSeconds = parseInt(refreshInterval);
    setCountdown(intervalSeconds);

    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          // Trigger refresh
          refetchQuote();
          refetchOptions();
          queryClient.invalidateQueries({ queryKey: ["/api/watchlist/quotes"] });
          return intervalSeconds;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [refreshInterval, isPaused, symbol, selectedExpiration, upstoxStatus?.connected, refetchQuote, refetchOptions]);

  // Detect option chain data changes and trigger auto-analyze
  useEffect(() => {
    if (!optionChain || !autoAnalyzeEnabled || !symbol || !selectedExpiration) return;

    // Create a hash from key OI data to detect changes
    const totalCallOI = optionChain.calls?.reduce((sum: number, c: any) => sum + (c.oi || 0), 0) || 0;
    const totalPutOI = optionChain.puts?.reduce((sum: number, p: any) => sum + (p.oi || 0), 0) || 0;
    const dataHash = `${totalCallOI}-${totalPutOI}-${optionChain.underlyingPrice}`;

    if (lastDataHashRef.current && lastDataHashRef.current !== dataHash) {
      // Data changed - trigger auto-analyze
      toast({
        title: "Data Changed",
        description: `${symbol} option chain updated. Re-analyzing...`,
        duration: 3000,
      });
      
      // Trigger analysis
      analyzeMutation.mutate();
    }
    
    lastDataHashRef.current = dataHash;
  }, [optionChain, autoAnalyzeEnabled, symbol, selectedExpiration, toast]);

  const handleUpstoxLogin = () => {
    if (upstoxLoginData?.authUrl) {
      window.open(upstoxLoginData.authUrl, "_blank", "width=600,height=700");
    }
  };

  const formatCountdown = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return mins > 0 ? `${mins}:${secs.toString().padStart(2, "0")}` : `${secs}s`;
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 sm:gap-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 sm:h-6 sm:w-6 text-primary" />
              <h1 className="text-lg sm:text-xl font-semibold">NSE/BSE Options</h1>
            </div>

            <div className="flex items-center gap-1 sm:gap-2">
              {upstoxStatus?.connected ? (
                <>
                  <Badge variant="outline" className="bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/30 text-xs">
                    <Link2 className="h-3 w-3 sm:mr-1" />
                    <span className="hidden sm:inline">Upstox Connected</span>
                  </Badge>
                  {symbol && refreshInterval !== "0" && !isPaused && (
                    <Badge 
                      variant="outline" 
                      className="bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/30 text-xs"
                      data-testid="badge-realtime-status"
                    >
                      <Wifi className="h-3 w-3 sm:mr-1" />
                      <span className="hidden sm:inline">Live {formatCountdown(countdown)}</span>
                      <span className="sm:hidden">{formatCountdown(countdown)}</span>
                    </Badge>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => disconnectUpstox.mutate()}
                    data-testid="button-upstox-disconnect"
                  >
                    <Link2Off className="h-4 w-4" />
                  </Button>
                </>
              ) : (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleUpstoxLogin}
                  data-testid="button-upstox-connect"
                  className="text-xs sm:text-sm"
                >
                  <Link2 className="h-4 w-4 sm:mr-1" />
                  <span className="hidden sm:inline">Connect Upstox</span>
                  <span className="sm:hidden">Connect</span>
                </Button>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2">
            {symbol && upstoxStatus?.connected && (
              <div className="flex items-center gap-2">
                <Select value={refreshInterval} onValueChange={setRefreshInterval}>
                  <SelectTrigger className="w-[100px]" data-testid="select-refresh-interval">
                    <SelectValue placeholder="Interval" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">Manual</SelectItem>
                    <SelectItem value="15">15s</SelectItem>
                    <SelectItem value="30">30s</SelectItem>
                    <SelectItem value="60">1min</SelectItem>
                  </SelectContent>
                </Select>
                
                {refreshInterval !== "0" && (
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => setIsPaused(!isPaused)}
                    data-testid="button-toggle-pause"
                  >
                    {isPaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
                  </Button>
                )}
                
                <Button
                  variant="outline"
                  size="icon"
                  onClick={handleRefresh}
                  disabled={isLoading}
                  data-testid="button-refresh"
                >
                  <RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
                </Button>
              </div>
            )}
            <ThemeToggle />
          </div>
        </div>

        {upstoxStatus?.connected && (
          <div className="max-w-[1600px] mx-auto px-4 sm:px-6 pb-3 pt-1">
            <StockSearch onSearch={handleSearch} isLoading={isLoadingQuote} />
          </div>
        )}
      </header>

      <main className="max-w-[1600px] mx-auto px-4 sm:px-6 py-6">
        {!upstoxStatus?.connected ? (
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
            <div className="bg-muted/50 rounded-full p-6 mb-6">
              <Link2 className="h-16 w-16 text-muted-foreground" />
            </div>
            <h2 className="text-2xl font-semibold mb-2">Connect to Upstox</h2>
            <p className="text-muted-foreground max-w-md mb-6">
              NSE/BSE option chain data பார்க்க Upstox account connect செய்யவும்.
            </p>
            <Button onClick={handleUpstoxLogin} data-testid="button-upstox-connect-main">
              <Link2 className="h-4 w-4 mr-2" />
              Connect Upstox Account
            </Button>
          </div>
        ) : !symbol ? (
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
            <div className="bg-muted/50 rounded-full p-6 mb-6">
              <BarChart3 className="h-16 w-16 text-muted-foreground" />
            </div>
            <h2 className="text-2xl font-semibold mb-2">Indian Market Options</h2>
            <p className="text-muted-foreground max-w-md">
              Index அல்லது stock தேர்ந்தெடுக்கவும் option chain பார்க்க.
            </p>
            <div className="flex gap-2 mt-6 flex-wrap justify-center">
              {INDIA_INDICES.map((sym) => (
                <button
                  key={sym}
                  onClick={() => handleSearch(sym)}
                  className="px-4 py-2 rounded-md bg-card border hover-elevate active-elevate-2 font-mono text-sm"
                  data-testid={`button-quick-${sym}`}
                >
                  {sym}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                {isLoadingQuote ? (
                  <Card>
                    <CardHeader>
                      <Skeleton className="h-8 w-24" />
                      <Skeleton className="h-4 w-48 mt-1" />
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-4 gap-4">
                        {[1, 2, 3, 4].map((i) => (
                          <div key={i}>
                            <Skeleton className="h-3 w-16 mb-2" />
                            <Skeleton className="h-8 w-24" />
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ) : quoteError ? (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      Stock data load ஆகவில்லை. Symbol சரிபார்த்து மீண்டும் முயற்சிக்கவும்.
                    </AlertDescription>
                  </Alert>
                ) : quote ? (
                  <StockQuoteCard quote={quote} optionChain={optionChain} />
                ) : null}
              </div>
              <div>
                <Watchlist 
                  currentSymbol={symbol} 
                  onSelectSymbol={handleSearch}
                />
              </div>
            </div>

            <Card className="overflow-visible">
              <div className="sticky top-[56px] sm:top-[88px] z-40 bg-card rounded-t-lg border-b">
                <CardHeader className="flex flex-row items-center justify-between gap-4 flex-wrap space-y-0 pb-2 pt-3">
                <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "chain" | "ai")} className="w-full">
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <TabsList className="h-9">
                      <TabsTrigger 
                        value="chain" 
                        className="gap-1.5 text-xs sm:text-sm"
                        data-testid="tab-option-chain"
                      >
                        <TableProperties className="h-3.5 w-3.5" />
                        Option Chain
                      </TabsTrigger>
                      <TabsTrigger 
                        value="ai" 
                        className="gap-1.5 text-xs sm:text-sm"
                        data-testid="tab-ai-analyze"
                        disabled={!optionChain}
                      >
                        <Brain className="h-3.5 w-3.5" />
                        AI Analyze
                        {analyzeMutation.isPending && (
                          <Loader2 className="h-3 w-3 animate-spin ml-1" />
                        )}
                      </TabsTrigger>
                    </TabsList>
                    <div className="flex items-center gap-2">
                      {expirationData?.expirationDates && (
                        <ExpirationSelector
                          expirationDates={expirationData.expirationDates}
                          selectedExpiration={selectedExpiration}
                          onSelect={setSelectedExpiration}
                        />
                      )}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowChart(true)}
                        className="text-xs gap-1"
                        disabled={!symbol}
                        data-testid="button-open-chart"
                      >
                        <CandlestickIcon className="h-3 w-3" />
                        <span className="hidden sm:inline">Chart</span>
                      </Button>
                      <Button
                        variant={autoAnalyzeEnabled ? "default" : "outline"}
                        size="sm"
                        onClick={() => setAutoAnalyzeEnabled(!autoAnalyzeEnabled)}
                        className={`text-xs gap-1 ${autoAnalyzeEnabled ? "bg-purple-600 hover:bg-purple-700" : ""}`}
                        data-testid="button-auto-analyze-toggle"
                      >
                        <Brain className="h-3 w-3" />
                        <span className="hidden sm:inline">Auto AI</span>
                        {autoAnalyzeEnabled && refreshInterval !== "0" && !isPaused && (
                          <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                        )}
                      </Button>
                    </div>
                  </div>
                </Tabs>
              </CardHeader>
              </div>
              <CardContent className="p-0 pt-2">
                <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "chain" | "ai")}>
                  <TabsContent value="chain" className="m-0">
                    {isLoadingOptions || isLoadingExpirations ? (
                      <div className="space-y-2 p-4">
                        <Skeleton className="h-10 w-full" />
                        {[1, 2, 3, 4, 5].map((i) => (
                          <Skeleton key={i} className="h-12 w-full" />
                        ))}
                      </div>
                    ) : optionsError ? (
                      <div className="p-4">
                        <Alert variant="destructive">
                          <AlertCircle className="h-4 w-4" />
                          <AlertDescription>
                            Option chain load ஆகவில்லை. மீண்டும் முயற்சிக்கவும்.
                          </AlertDescription>
                        </Alert>
                      </div>
                    ) : optionChain ? (
                      <OptionChainTable
                        calls={optionChain.calls}
                        puts={optionChain.puts}
                        underlyingPrice={optionChain.underlyingPrice}
                        summary={optionChain.summary}
                      />
                    ) : (
                      <div className="text-center py-8 text-muted-foreground">
                        Expiry date தேர்ந்தெடுக்கவும்
                      </div>
                    )}
                  </TabsContent>
                  <TabsContent value="ai" className="m-0">
                    <div className="min-h-[400px] p-4">
                      {analyzeMutation.isPending || isLoadingAnalysis ? (
                        <div className="flex flex-col items-center justify-center py-12 gap-3">
                          <Loader2 className="h-8 w-8 animate-spin text-purple-600" />
                          <p className="text-sm text-muted-foreground">
                            AI analyzing {symbol} option chain...
                          </p>
                          <p className="text-xs text-muted-foreground">
                            Support/Resistance, CE/PE trends கணக்கிடுகிறது...
                          </p>
                        </div>
                      ) : analysisData?.analysis ? (
                        <div className="prose prose-sm dark:prose-invert max-w-none">
                          <div className="whitespace-pre-wrap text-sm leading-relaxed">
                            {analysisData.analysis}
                          </div>
                          <div className="flex items-center justify-between flex-wrap gap-2 mt-4 pt-3 border-t text-xs text-muted-foreground">
                            <span>Generated: {new Date(analysisData.createdAt).toLocaleString("en-IN")}</span>
                            <div className="flex items-center gap-2">
                              <Button
                                variant={showChat ? "default" : "outline"}
                                size="sm"
                                onClick={() => setShowChat(!showChat)}
                                data-testid="button-toggle-chat"
                              >
                                <MessageCircle className="h-3 w-3 mr-1" />
                                {showChat ? "Close Chat" : "Ask AI"}
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => analyzeMutation.mutate()}
                                disabled={analyzeMutation.isPending}
                                data-testid="button-refresh-analysis"
                              >
                                <Brain className="h-3 w-3 mr-1" />
                                Re-analyze
                              </Button>
                            </div>
                          </div>
                          <AIChatBox
                            symbol={symbol}
                            expirationDate={selectedExpiration}
                            isVisible={showChat}
                          />
                        </div>
                      ) : analyzeMutation.isError ? (
                        <div className="py-8">
                          <Alert variant="destructive">
                            <AlertCircle className="h-4 w-4" />
                            <AlertDescription>
                              Analysis failed. மீண்டும் முயற்சிக்கவும்.
                            </AlertDescription>
                          </Alert>
                          <div className="text-center mt-4">
                            <Button
                              variant="outline"
                              onClick={() => analyzeMutation.mutate()}
                              data-testid="button-retry-analysis"
                            >
                              <Brain className="h-4 w-4 mr-2" />
                              Try Again
                            </Button>
                          </div>
                        </div>
                      ) : optionChain ? (
                        <div className="flex flex-col items-center justify-center py-12 gap-4">
                          <Brain className="h-12 w-12 text-purple-500/50" />
                          <p className="text-muted-foreground text-center">
                            AI Analysis பெற click செய்யவும்
                          </p>
                          <Button
                            onClick={() => analyzeMutation.mutate()}
                            className="bg-purple-600 hover:bg-purple-700"
                            data-testid="button-start-analysis"
                          >
                            <Brain className="h-4 w-4 mr-2" />
                            Start AI Analysis
                          </Button>
                        </div>
                      ) : (
                        <div className="text-center py-12 text-muted-foreground">
                          Option chain data load ஆன பிறகு analysis செய்யலாம்
                        </div>
                      )}
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        )}
      </main>

      {/* Candlestick Chart Dialog */}
      <CandlestickChart
        symbol={symbol}
        isOpen={showChart}
        onClose={() => setShowChart(false)}
        currentPrice={quote?.regularMarketPrice}
      />
    </div>
  );
}
