import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, real, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Watchlist items - stocks user is tracking
export const watchlistItems = pgTable("watchlist_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  symbol: text("symbol").notNull(),
  addedAt: timestamp("added_at").defaultNow().notNull(),
});

export const insertWatchlistItemSchema = createInsertSchema(watchlistItems).pick({
  symbol: true,
});

export type InsertWatchlistItem = z.infer<typeof insertWatchlistItemSchema>;
export type WatchlistItem = typeof watchlistItems.$inferSelect;

// AI Analysis results
export const aiAnalyses = pgTable("ai_analyses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  symbol: text("symbol").notNull(),
  expirationDate: text("expiration_date").notNull(),
  analysis: text("analysis").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Upstox OAuth tokens - persisted for session continuity
export const upstoxTokens = pgTable("upstox_tokens", {
  id: varchar("id").primaryKey().default("default"),
  accessToken: text("access_token").notNull(),
  expiry: timestamp("expiry").notNull(),
  savedAt: timestamp("saved_at").defaultNow().notNull(),
});

export type UpstoxTokenRecord = typeof upstoxTokens.$inferSelect;

// AI Chat conversations
export const chatConversations = pgTable("chat_conversations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  symbol: text("symbol").notNull(),
  expirationDate: text("expiration_date").notNull(),
  analysisId: varchar("analysis_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertChatConversationSchema = createInsertSchema(chatConversations).pick({
  symbol: true,
  expirationDate: true,
  analysisId: true,
});

export type InsertChatConversation = z.infer<typeof insertChatConversationSchema>;
export type ChatConversation = typeof chatConversations.$inferSelect;

// AI Chat messages
export const chatMessages = pgTable("chat_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  conversationId: varchar("conversation_id").notNull(),
  role: text("role").notNull(), // 'user' | 'assistant'
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).pick({
  conversationId: true,
  role: true,
  content: true,
});

export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;

export const insertAiAnalysisSchema = createInsertSchema(aiAnalyses).pick({
  symbol: true,
  expirationDate: true,
  analysis: true,
});

export type InsertAiAnalysis = z.infer<typeof insertAiAnalysisSchema>;
export type AiAnalysis = typeof aiAnalyses.$inferSelect;

// Types for option chain data (not stored in DB, fetched from API)
export interface OptionContract {
  contractSymbol: string;
  strike: number;
  lastPrice: number;
  bid: number;
  ask: number;
  change: number;
  percentChange: number;
  volume: number;
  openInterest: number;
  oiChange: number;
  impliedVolatility: number;
  inTheMoney: boolean;
  delta?: number;
  gamma?: number;
  theta?: number;
  vega?: number;
}

export interface OptionChainSummary {
  spotPrice: number;
  maxPain: number;
  pcr: number;
  totalCallOI: number;
  totalPutOI: number;
  ceBuildup: number;
  peBuildup: number;
  trendDirection: "CE_BUILDUP" | "PE_BUILDUP" | "NEUTRAL";
  atmStrike: number;
  vix?: number;
}

export interface OptionChainData {
  symbol: string;
  underlyingPrice: number;
  expirationDates: string[];
  selectedExpiration: string;
  calls: OptionContract[];
  puts: OptionContract[];
  summary: OptionChainSummary;
  lastUpdated: string;
}

export interface StockQuote {
  symbol: string;
  shortName: string;
  regularMarketPrice: number;
  regularMarketChange: number;
  regularMarketChangePercent: number;
  regularMarketVolume: number;
  marketCap: number;
  open: number;
  high: number;
  low: number;
  close: number;
  previousClose: number;
  yearHigh: number;
  yearLow: number;
  timestamp?: string;
}

// Zod schemas for validation
export const optionContractSchema = z.object({
  contractSymbol: z.string(),
  strike: z.number(),
  lastPrice: z.number(),
  bid: z.number(),
  ask: z.number(),
  change: z.number(),
  percentChange: z.number(),
  volume: z.number(),
  openInterest: z.number(),
  oiChange: z.number(),
  impliedVolatility: z.number(),
  inTheMoney: z.boolean(),
  delta: z.number().optional(),
  gamma: z.number().optional(),
  theta: z.number().optional(),
  vega: z.number().optional(),
});

export const optionChainSummarySchema = z.object({
  spotPrice: z.number(),
  maxPain: z.number(),
  pcr: z.number(),
  totalCallOI: z.number(),
  totalPutOI: z.number(),
  ceBuildup: z.number(),
  peBuildup: z.number(),
  trendDirection: z.enum(["CE_BUILDUP", "PE_BUILDUP", "NEUTRAL"]),
  atmStrike: z.number(),
  vix: z.number().optional(),
});

export const optionChainDataSchema = z.object({
  symbol: z.string(),
  underlyingPrice: z.number(),
  expirationDates: z.array(z.string()),
  selectedExpiration: z.string(),
  calls: z.array(optionContractSchema),
  puts: z.array(optionContractSchema),
  summary: optionChainSummarySchema,
  lastUpdated: z.string(),
});

export const stockQuoteSchema = z.object({
  symbol: z.string(),
  shortName: z.string(),
  regularMarketPrice: z.number(),
  regularMarketChange: z.number(),
  regularMarketChangePercent: z.number(),
  regularMarketVolume: z.number(),
  marketCap: z.number(),
  open: z.number(),
  high: z.number(),
  low: z.number(),
  close: z.number(),
  previousClose: z.number(),
  yearHigh: z.number(),
  yearLow: z.number(),
  timestamp: z.string().optional(),
});
